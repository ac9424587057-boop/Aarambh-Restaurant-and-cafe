/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect, useMemo } from 'react';
import {
  PageId,
  MenuCategoryId,
  MenuItem,
  MenuAddOn,
  CartItem,
} from './types/restaurant';
import { RESTAURANT_CONFIG } from './data/restaurantConfig';
import { Navigation } from './components/Navigation';
import { CartDrawer } from './components/CartDrawer';
import { Footer } from './components/Footer';
import { HomePage } from './pages/HomePage';
import { MenuPage } from './pages/MenuPage';
import { AboutPage } from './pages/AboutPage';
import { GalleryPage } from './pages/GalleryPage';
import { ContactPage } from './pages/ContactPage';
import { OrderPage } from './pages/OrderPage';
import { LegalPage } from './pages/LegalPage';

const CART_STORAGE_KEY = 'aarambh_restaurant_cart_v1';

const PAGE_TITLES: Record<PageId, string> = {
  home: 'Aarambh Restaurant and Cafe | Restaurant in Shivpuri',
  menu: 'Menu & Indicative Prices | Aarambh Restaurant and Cafe, Shivpuri',
  about: 'About Us | Aarambh Restaurant and Cafe, Thakur Pura, Shivpuri',
  gallery: 'Food & Cafe Gallery | Aarambh Restaurant and Cafe, Shivpuri',
  contact: 'Contact & Location | Aarambh Restaurant and Cafe, Shivpuri',
  order: 'Order Online via WhatsApp | Aarambh Restaurant and Cafe',
  legal: 'Privacy Policy & Order Terms | Aarambh Restaurant and Cafe',
};

function parseHashToPage(hash: string): PageId {
  const cleaned = hash.replace('#', '').trim().toLowerCase();
  const validPages: PageId[] = [
    'home',
    'menu',
    'about',
    'gallery',
    'contact',
    'order',
    'legal',
  ];
  if (validPages.includes(cleaned as PageId)) {
    return cleaned as PageId;
  }
  return 'home';
}

export default function App() {
  const [currentPage, setCurrentPage] = useState<PageId>(() =>
    parseHashToPage(window.location.hash)
  );
  const [activeMenuCategory, setActiveMenuCategory] =
    useState<MenuCategoryId>('all');
  const [isCartDrawerOpen, setIsCartDrawerOpen] = useState<boolean>(false);

  // Persistent client-side cart
  const [cart, setCart] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem(CART_STORAGE_KEY);
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem(CART_STORAGE_KEY, JSON.stringify(cart));
    } catch {
      // Ignore storage quota errors in restricted frames
    }
  }, [cart]);

  // Sync URL hash and document title for SEO & browser navigation
  useEffect(() => {
    const onHashChange = () => {
      setCurrentPage(parseHashToPage(window.location.hash));
    };
    window.addEventListener('hashchange', onHashChange);
    return () => window.removeEventListener('hashchange', onHashChange);
  }, []);

  useEffect(() => {
    document.title =
      PAGE_TITLES[currentPage] ||
      `${RESTAURANT_CONFIG.brandName} | Restaurant in Shivpuri`;
    if (window.location.hash !== `#${currentPage}`) {
      window.history.replaceState(null, '', `#${currentPage}`);
    }
  }, [currentPage]);

  const handleNavigate = (page: PageId) => {
    setCurrentPage(page);
  };

  const handleSelectCategoryAndNavigate = (category: MenuCategoryId) => {
    setActiveMenuCategory(category);
    setCurrentPage('menu');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Cart Operations
  const handleAddToCart = (
    menuItem: MenuItem,
    quantity: number,
    selectedAddOns: MenuAddOn[]
  ) => {
    const sortedAddOnIds = [...selectedAddOns]
      .map((a) => a.id)
      .sort()
      .join('|');
    const cartItemId = `${menuItem.id}::${sortedAddOnIds}`;

    setCart((prev) => {
      const existingIndex = prev.findIndex((i) => i.cartItemId === cartItemId);
      if (existingIndex > -1) {
        const updated = [...prev];
        updated[existingIndex] = {
          ...updated[existingIndex],
          quantity: updated[existingIndex].quantity + quantity,
        };
        return updated;
      }
      return [
        ...prev,
        {
          cartItemId,
          menuItem,
          quantity,
          selectedAddOns,
        },
      ];
    });
  };

  const handleUpdateQuantity = (cartItemId: string, delta: number) => {
    setCart((prev) =>
      prev
        .map((item) =>
          item.cartItemId === cartItemId
            ? { ...item, quantity: item.quantity + delta }
            : item
        )
        .filter((item) => item.quantity > 0)
    );
  };

  const handleRemoveItem = (cartItemId: string) => {
    setCart((prev) => prev.filter((item) => item.cartItemId !== cartItemId));
  };

  const handleClearCart = () => {
    setCart([]);
  };

  const cartCount = useMemo(
    () => cart.reduce((total, item) => total + item.quantity, 0),
    [cart]
  );

  const cartSubtotal = useMemo(
    () =>
      cart.reduce((total, item) => {
        const addOnsCost = item.selectedAddOns.reduce(
          (sum, a) => sum + a.price,
          0
        );
        return total + (item.menuItem.price + addOnsCost) * item.quantity;
      }, 0),
    [cart]
  );

  return (
    <div className="min-h-screen flex flex-col bg-[#FFF8ED] text-[#242821]">
      {/* Skip to Main Content for Keyboard Accessibility */}
      <a
        href="#main-content"
        className="sr-only focus:not-sr-only focus:fixed focus:top-2 focus:left-2 focus:z-50 focus:px-4 focus:py-2 focus:bg-[#173D30] focus:text-[#FFF8ED] focus:rounded-lg focus:text-sm focus:font-semibold"
      >
        Skip to main content
      </a>

      {/* Top Navigation & Mobile Sticky Bottom Action Bar */}
      <Navigation
        currentPage={currentPage}
        onNavigate={handleNavigate}
        cartCount={cartCount}
        onOpenCart={() => setIsCartDrawerOpen(true)}
      />

      {/* Main Page Router */}
      <main id="main-content" className="flex-1">
        {currentPage === 'home' && (
          <HomePage
            onNavigate={handleNavigate}
            onSelectCategoryAndNavigate={handleSelectCategoryAndNavigate}
            onAddToCart={handleAddToCart}
          />
        )}

        {currentPage === 'menu' && (
          <MenuPage
            initialCategory={activeMenuCategory}
            onAddToCart={handleAddToCart}
            cartCount={cartCount}
            cartSubtotal={cartSubtotal}
            onNavigate={handleNavigate}
          />
        )}

        {currentPage === 'about' && <AboutPage onNavigate={handleNavigate} />}

        {currentPage === 'gallery' && (
          <GalleryPage onNavigate={handleNavigate} />
        )}

        {currentPage === 'contact' && <ContactPage />}

        {currentPage === 'order' && (
          <OrderPage
            cart={cart}
            onUpdateQuantity={handleUpdateQuantity}
            onRemoveItem={handleRemoveItem}
            onClearCart={handleClearCart}
            onAddToCart={handleAddToCart}
            subtotal={cartSubtotal}
            onNavigate={handleNavigate}
          />
        )}

        {currentPage === 'legal' && <LegalPage />}
      </main>

      {/* Slide-over Cart Drawer */}
      <CartDrawer
        isOpen={isCartDrawerOpen}
        onClose={() => setIsCartDrawerOpen(false)}
        cart={cart}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveItem}
        onClearCart={handleClearCart}
        subtotal={cartSubtotal}
        onProceedToCheckout={(page) => {
          handleNavigate(page);
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
      />

      {/* Footer */}
      <Footer onNavigate={handleNavigate} />
    </div>
  );
}
