import React, { useState } from 'react';
import {
  ShoppingBag,
  PhoneCall,
  UtensilsCrossed,
  Menu as MenuIcon,
  X,
  MapPin,
  Clock,
} from 'lucide-react';
import { PageId } from '../types/restaurant';
import { RESTAURANT_CONFIG } from '../data/restaurantConfig';

interface NavigationProps {
  currentPage: PageId;
  onNavigate: (page: PageId) => void;
  cartCount: number;
  onOpenCart: () => void;
}

export const Navigation: React.FC<NavigationProps> = ({
  currentPage,
  onNavigate,
  cartCount,
  onOpenCart,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [announcementDismissed, setAnnouncementDismissed] = useState(false);

  const primaryNavLinks: { id: PageId; label: string }[] = [
    { id: 'home', label: 'Home' },
    { id: 'menu', label: 'Menu' },
    { id: 'about', label: 'About Us' },
    { id: 'gallery', label: 'Food Gallery' },
    { id: 'contact', label: 'Contact & Location' },
  ];

  const handleNavClick = (page: PageId) => {
    onNavigate(page);
    setMobileMenuOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <>
      {/* Configurable Announcement Bar (Slim <= 36px on desktop, hidden on mobile to preserve 15% sticky viewport budget) */}
      {!announcementDismissed && (
        <div
          role="region"
          aria-label="Opening Hours and Location Announcement"
          className="hidden sm:block bg-[#173D30] text-[#FFF8ED] border-b border-[#D5AC65]/25 text-xs"
        >
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-9 flex items-center justify-between gap-4">
            <div className="flex items-center gap-3 truncate">
              <span className="inline-flex items-center gap-1.5 text-[#D5AC65] font-medium shrink-0">
                <Clock className="w-3.5 h-3.5" aria-hidden="true" />
                <span>{RESTAURANT_CONFIG.openingHours.statusNote}</span>
              </span>
              <span aria-hidden="true" className="text-[#FFF8ED]/40">
                ·
              </span>
              <span className="inline-flex items-center gap-1 text-[#FFF8ED]/85 truncate">
                <MapPin className="w-3.5 h-3.5 text-[#C86F4A] shrink-0" aria-hidden="true" />
                <span className="truncate">
                  {RESTAURANT_CONFIG.location.area}, {RESTAURANT_CONFIG.location.city} ({RESTAURANT_CONFIG.location.landmarkReference})
                </span>
              </span>
            </div>
            <div className="flex items-center gap-4 shrink-0">
              <a
                href={`tel:${RESTAURANT_CONFIG.contact.phoneDial}`}
                className="text-[#FFF8ED] hover:text-[#D5AC65] transition-colors font-mono-num whitespace-nowrap"
              >
                Call: {RESTAURANT_CONFIG.contact.phoneDisplay}
              </a>
              <button
                type="button"
                onClick={() => setAnnouncementDismissed(true)}
                aria-label="Dismiss announcement bar"
                className="text-[#FFF8ED]/60 hover:text-[#FFF8ED] p-1 focus-visible:outline-2 focus-visible:outline-[#D5AC65] rounded"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Top Navigation Bar — Strict 3-Zone Contract */}
      <header className="sticky top-0 z-40 bg-[#FFF8ED]/95 backdrop-blur-md border-b border-[#173D30]/12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-14 sm:h-16 flex items-center justify-between gap-8">
          {/* Zone 1: Single-line Brand Wordmark */}
          <button
            type="button"
            onClick={() => handleNavClick('home')}
            className="text-left text-lg sm:text-xl font-bold font-serif-display tracking-tight text-[#173D30] hover:text-[#C86F4A] transition-colors whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-[#173D30] rounded"
          >
            {RESTAURANT_CONFIG.brandName}
          </button>

          {/* Zone 2: 5 Single-Line Navigation Links */}
          <nav
            aria-label="Primary Navigation"
            className="hidden lg:flex items-center gap-7 text-sm font-medium text-[#242821]/80"
          >
            {primaryNavLinks.map((link) => {
              const isActive = currentPage === link.id;
              return (
                <button
                  key={link.id}
                  type="button"
                  onClick={() => handleNavClick(link.id)}
                  aria-current={isActive ? 'page' : undefined}
                  className={`py-1 whitespace-nowrap shrink-0 transition-colors border-b-2 focus-visible:outline-2 focus-visible:outline-[#173D30] ${
                    isActive
                      ? 'border-[#C86F4A] text-[#173D30] font-semibold'
                      : 'border-transparent hover:text-[#173D30] hover:border-[#173D30]/30'
                  }`}
                >
                  {link.label}
                </button>
              );
            })}
          </nav>

          {/* Zone 3: 1 Primary Action (Order / Cart Trigger) + Mobile Drawer Toggle */}
          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={onOpenCart}
              aria-label={`Order Online and View Cart (${cartCount} items)`}
              className="inline-flex items-center gap-2 px-4 py-2 text-xs sm:text-sm font-semibold text-[#FFF8ED] bg-[#173D30] hover:bg-[#173D30]/90 rounded-lg transition-colors whitespace-nowrap shrink-0 min-h-[40px] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#173D30]"
            >
              <ShoppingBag className="w-4 h-4 text-[#D5AC65]" aria-hidden="true" />
              <span>Order Online</span>
              <span className="font-mono-num text-[#D5AC65]">({cartCount})</span>
            </button>

            <button
              type="button"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              aria-expanded={mobileMenuOpen}
              aria-label="Toggle navigation menu"
              className="lg:hidden inline-flex items-center justify-center w-10 h-10 rounded-lg text-[#173D30] hover:bg-[#173D30]/10 transition-colors focus-visible:outline-2 focus-visible:outline-[#173D30]"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <MenuIcon className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* Mobile Dropdown Menu */}
        {mobileMenuOpen && (
          <div className="lg:hidden bg-[#FFF8ED] border-b border-[#173D30]/15 px-4 pt-2 pb-5 space-y-2 shadow-lg">
            <div className="py-2 px-3 bg-[#173D30]/5 rounded-lg text-xs text-[#242821]/80 space-y-1">
              <p className="font-medium text-[#173D30]">
                {RESTAURANT_CONFIG.openingHours.statusNote}
              </p>
              <p>{RESTAURANT_CONFIG.location.fullAddress}</p>
            </div>

            <nav aria-label="Mobile Navigation" className="grid grid-cols-1 gap-1 pt-1">
              {[
                ...primaryNavLinks,
                { id: 'order' as PageId, label: 'Order Online & Checkout' },
                { id: 'legal' as PageId, label: 'Privacy Policy & Terms' },
              ].map((item) => {
                const isActive = currentPage === item.id;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => handleNavClick(item.id)}
                    className={`w-full text-left px-3 py-2.5 rounded-lg text-sm font-medium transition-colors flex items-center justify-between min-h-[44px] ${
                      isActive
                        ? 'bg-[#173D30] text-[#FFF8ED]'
                        : 'text-[#242821] hover:bg-[#173D30]/8'
                    }`}
                  >
                    <span>{item.label}</span>
                    {item.id === 'order' && cartCount > 0 && (
                      <span className="font-mono-num text-xs text-[#D5AC65]">
                        {cartCount} in cart
                      </span>
                    )}
                  </button>
                );
              })}
            </nav>
          </div>
        )}
      </header>

      {/* Mobile Sticky Bottom Action Bar: Menu, Call, and Order (Compact <= 52px to respect 15% mobile sticky cap) */}
      <div
        role="navigation"
        aria-label="Mobile Quick Actions"
        className="md:hidden fixed bottom-0 inset-x-0 z-40 bg-[#173D30] text-[#FFF8ED] border-t border-[#D5AC65]/30 shadow-lg"
      >
        <div className="grid grid-cols-3 h-12 max-w-md mx-auto">
          <button
            type="button"
            onClick={() => handleNavClick('menu')}
            className={`flex items-center justify-center gap-1.5 text-xs font-medium transition-colors min-h-[44px] focus-visible:outline-2 focus-visible:outline-[#D5AC65] ${
              currentPage === 'menu' ? 'text-[#D5AC65] font-semibold' : 'text-[#FFF8ED]'
            }`}
          >
            <UtensilsCrossed className="w-4 h-4 shrink-0" aria-hidden="true" />
            <span className="whitespace-nowrap">Menu</span>
          </button>

          <a
            href={`tel:${RESTAURANT_CONFIG.contact.phoneDial}`}
            className="flex items-center justify-center gap-1.5 text-xs font-medium text-[#FFF8ED] hover:text-[#D5AC65] border-x border-[#FFF8ED]/15 transition-colors min-h-[44px] focus-visible:outline-2 focus-visible:outline-[#D5AC65]"
          >
            <PhoneCall className="w-4 h-4 shrink-0 text-[#D5AC65]" aria-hidden="true" />
            <span className="whitespace-nowrap">Call</span>
          </a>

          <button
            type="button"
            onClick={() => handleNavClick('order')}
            className="flex items-center justify-center gap-1.5 text-xs font-semibold bg-[#C86F4A] text-[#FFF8ED] hover:bg-[#C86F4A]/90 transition-colors min-h-[44px] focus-visible:outline-2 focus-visible:outline-[#D5AC65]"
          >
            <ShoppingBag className="w-4 h-4 shrink-0" aria-hidden="true" />
            <span className="whitespace-nowrap font-mono-num">
              Order {cartCount > 0 ? `(${cartCount})` : ''}
            </span>
          </button>
        </div>
      </div>
    </>
  );
};
