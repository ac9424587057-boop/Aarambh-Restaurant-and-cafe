import React from 'react';
import { MapPin, Phone, Clock, ExternalLink, MessageCircle } from 'lucide-react';
import { PageId } from '../types/restaurant';
import { RESTAURANT_CONFIG, buildWhatsAppEnquiryUrl } from '../data/restaurantConfig';

interface FooterProps {
  onNavigate: (page: PageId) => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavigate }) => {
  const handleLink = (page: PageId) => {
    onNavigate(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-[#173D30] text-[#FFF8ED] border-t border-[#D5AC65]/25 pb-20 md:pb-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-14 pb-10">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">
          {/* Column 1: Brand & Story */}
          <div className="space-y-3">
            <h2 className="font-serif-display text-2xl font-bold text-[#FFF8ED]">
              {RESTAURANT_CONFIG.brandName}
            </h2>
            <p className="text-xs font-medium text-[#D5AC65]">
              {RESTAURANT_CONFIG.tagline} · {RESTAURANT_CONFIG.location.city}, {RESTAURANT_CONFIG.location.state}
            </p>
            <p className="text-sm text-[#FFF8ED]/80 leading-relaxed">
              Welcoming families, students, couples and takeaway guests in Thakur Pura, Shivpuri with freshly prepared North Indian curries, Indo-Chinese starters, cafe favourites and beverages.
            </p>
          </div>

          {/* Column 2: Quick Links */}
          <div className="space-y-3">
            <h3 className="font-serif-display text-base font-semibold text-[#D5AC65]">
              Explore Pages
            </h3>
            <ul className="space-y-2 text-sm text-[#FFF8ED]/85">
              {(
                [
                  { id: 'home', label: 'Home' },
                  { id: 'menu', label: 'Full Menu & Indicative Prices' },
                  { id: 'order', label: 'Order Online via WhatsApp' },
                  { id: 'about', label: 'About Aarambh Restaurant' },
                  { id: 'gallery', label: 'Food Gallery' },
                  { id: 'contact', label: 'Contact & Directions' },
                  { id: 'legal', label: 'Privacy Policy & Order Terms' },
                ] as { id: PageId; label: string }[]
              ).map((item) => (
                <li key={item.id}>
                  <button
                    type="button"
                    onClick={() => handleLink(item.id)}
                    className="hover:text-[#D5AC65] transition-colors text-left"
                  >
                    {item.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Column 3: Address & Landmark */}
          <div className="space-y-3">
            <h3 className="font-serif-display text-base font-semibold text-[#D5AC65]">
              Location & Hours
            </h3>
            <div className="space-y-2.5 text-sm text-[#FFF8ED]/85">
              <p className="flex items-start gap-2.5">
                <MapPin className="w-4 h-4 text-[#C86F4A] shrink-0 mt-1" aria-hidden="true" />
                <span>{RESTAURANT_CONFIG.location.fullAddress}</span>
              </p>
              <p className="flex items-start gap-2.5">
                <Clock className="w-4 h-4 text-[#D5AC65] shrink-0 mt-1" aria-hidden="true" />
                <span>{RESTAURANT_CONFIG.openingHours.scheduleSummary}</span>
              </p>
              <div className="pt-1">
                <a
                  href={RESTAURANT_CONFIG.location.googleMapsUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#D5AC65] hover:underline"
                >
                  <span>Open in Google Maps</span>
                  <ExternalLink className="w-3.5 h-3.5" aria-hidden="true" />
                </a>
              </div>
            </div>
          </div>

          {/* Column 4: Direct Contact & WhatsApp */}
          <div className="space-y-3">
            <h3 className="font-serif-display text-base font-semibold text-[#D5AC65]">
              Order & Enquiries
            </h3>
            <p className="text-sm text-[#FFF8ED]/80">
              Have a question about today’s dishes, family seating or takeaway preparation time? Reach us directly:
            </p>
            <div className="space-y-2.5 pt-1">
              <a
                href={`tel:${RESTAURANT_CONFIG.contact.phoneDial}`}
                className="w-full py-2.5 px-4 rounded-lg bg-white/10 hover:bg-white/15 text-[#FFF8ED] text-sm font-medium flex items-center justify-center gap-2 transition-colors font-mono-num"
              >
                <Phone className="w-4 h-4 text-[#D5AC65]" aria-hidden="true" />
                <span>{RESTAURANT_CONFIG.contact.phoneDisplay}</span>
              </a>

              <a
                href={buildWhatsAppEnquiryUrl()}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full py-2.5 px-4 rounded-lg bg-[#C86F4A] hover:bg-[#C86F4A]/90 text-[#FFF8ED] text-sm font-semibold flex items-center justify-center gap-2 transition-colors"
              >
                <MessageCircle className="w-4 h-4" aria-hidden="true" />
                <span>Chat on WhatsApp</span>
              </a>
            </div>
          </div>
        </div>

        {/* Disclaimers & Copyright */}
        <div className="mt-12 pt-6 border-t border-[#FFF8ED]/15 text-xs text-[#FFF8ED]/65 space-y-2">
          <p>{RESTAURANT_CONFIG.pricingDisclaimer.bannerText}</p>
          <p>{RESTAURANT_CONFIG.imageDisclaimer}</p>
          <div className="pt-2 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-[#FFF8ED]/75">
            <p>
              © {new Date().getFullYear()} {RESTAURANT_CONFIG.brandName}, Thakur Pura, Shivpuri (MP). All rights reserved.
            </p>
            <div className="flex items-center gap-4">
              <button
                type="button"
                onClick={() => handleLink('legal')}
                className="hover:text-[#D5AC65] underline"
              >
                Privacy Policy & Order Terms
              </button>
              <button
                type="button"
                onClick={() => handleLink('contact')}
                className="hover:text-[#D5AC65] underline"
              >
                Sitemap & Local Info
              </button>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};
