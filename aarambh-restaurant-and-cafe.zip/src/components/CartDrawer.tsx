import React from 'react';
import { X, Trash2, ShoppingBag, ArrowRight, MessageCircle } from 'lucide-react';
import { CartItem, PageId } from '../types/restaurant';
import { RESTAURANT_CONFIG } from '../data/restaurantConfig';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  cart: CartItem[];
  onUpdateQuantity: (cartItemId: string, delta: number) => void;
  onRemoveItem: (cartItemId: string) => void;
  onClearCart: () => void;
  subtotal: number;
  onProceedToCheckout: (page: PageId) => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  cart,
  onUpdateQuantity,
  onRemoveItem,
  onClearCart,
  subtotal,
  onProceedToCheckout,
}) => {
  if (!isOpen) return null;

  const totalItems = cart.reduce((acc, item) => acc + item.quantity, 0);

  return (
    <div
      className="fixed inset-0 z-50 overflow-hidden"
      role="dialog"
      aria-modal="true"
      aria-labelledby="cart-drawer-title"
    >
      {/* Scrim Backdrop */}
      <div
        onClick={onClose}
        className="fixed inset-0 bg-black/60 backdrop-blur-xs transition-opacity"
        aria-hidden="true"
      />

      <div className="fixed inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-md bg-[#FFF8ED] text-[#242821] shadow-2xl flex flex-col justify-between border-l border-[#173D30]/15">
          {/* Header */}
          <div className="p-5 bg-[#173D30] text-[#FFF8ED] flex items-center justify-between border-b border-[#D5AC65]/25">
            <div className="flex items-center gap-2.5">
              <ShoppingBag className="w-5 h-5 text-[#D5AC65]" aria-hidden="true" />
              <h2
                id="cart-drawer-title"
                className="font-serif-display text-lg font-semibold"
              >
                Your Order Request ({totalItems})
              </h2>
            </div>
            <button
              type="button"
              onClick={onClose}
              aria-label="Close order drawer"
              className="p-2 rounded-lg text-[#FFF8ED]/80 hover:text-[#FFF8ED] hover:bg-white/10 transition-colors focus-visible:outline-2 focus-visible:outline-[#D5AC65]"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Cart Body */}
          <div className="flex-1 overflow-y-auto p-5 space-y-4">
            {cart.length === 0 ? (
              <div className="text-center py-12 px-4 space-y-4">
                <div className="w-14 h-14 rounded-full bg-[#173D30]/10 text-[#173D30] flex items-center justify-center mx-auto">
                  <ShoppingBag className="w-7 h-7" />
                </div>
                <h3 className="font-serif-display text-xl font-semibold text-[#173D30]">
                  Your order tray is empty
                </h3>
                <p className="text-sm text-[#242821]/75 max-w-xs mx-auto">
                  Explore our North Indian mains, Indo-Chinese starters, cafe snacks, cold coffee and desserts to build your WhatsApp order request.
                </p>
                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    onProceedToCheckout('menu');
                  }}
                  className="mt-2 inline-flex items-center gap-2 px-5 py-2.5 rounded-lg bg-[#173D30] text-[#FFF8ED] text-sm font-semibold hover:bg-[#C86F4A] transition-colors"
                >
                  <span>Browse Full Menu</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <>
                <div className="flex items-center justify-between text-xs text-[#242821]/70 pb-2 border-b border-[#173D30]/10">
                  <span>Selected Dishes</span>
                  <button
                    type="button"
                    onClick={onClearCart}
                    className="inline-flex items-center gap-1 text-[#C86F4A] hover:underline font-medium"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Clear Cart</span>
                  </button>
                </div>

                <ul className="divide-y divide-[#173D30]/10">
                  {cart.map((item) => {
                    const addOnCost = item.selectedAddOns.reduce(
                      (sum, a) => sum + a.price,
                      0
                    );
                    const itemUnitCost = item.menuItem.price + addOnCost;
                    const itemTotal = itemUnitCost * item.quantity;

                    return (
                      <li key={item.cartItemId} className="py-4 space-y-2">
                        <div className="flex items-start justify-between gap-3">
                          <div>
                            <h4 className="font-semibold text-sm text-[#242821]">
                              {item.menuItem.name}
                            </h4>
                            <p className="text-xs text-[#242821]/65 font-mono-num">
                              {RESTAURANT_CONFIG.currency.symbol}
                              {item.menuItem.price} base (indicative)
                            </p>
                            {item.selectedAddOns.length > 0 && (
                              <p className="text-xs text-[#173D30] mt-1">
                                + Add-ons:{' '}
                                {item.selectedAddOns
                                  .map((a) => `${a.name} (₹${a.price})`)
                                  .join(', ')}
                              </p>
                            )}
                          </div>
                          <span className="font-mono-num text-sm font-semibold text-[#173D30]">
                            {RESTAURANT_CONFIG.currency.symbol}
                            {itemTotal}
                          </span>
                        </div>

                        <div className="flex items-center justify-between pt-1">
                          <div className="inline-flex items-center border border-[#173D30]/20 rounded-lg bg-white">
                            <button
                              type="button"
                              onClick={() => onUpdateQuantity(item.cartItemId, -1)}
                              aria-label={`Decrease ${item.menuItem.name} quantity`}
                              className="w-8 h-8 flex items-center justify-center text-sm font-semibold text-[#173D30] hover:bg-[#173D30]/10 rounded-l-lg"
                            >
                              −
                            </button>
                            <span className="w-8 text-center font-mono-num text-xs font-semibold">
                              {item.quantity}
                            </span>
                            <button
                              type="button"
                              onClick={() => onUpdateQuantity(item.cartItemId, 1)}
                              aria-label={`Increase ${item.menuItem.name} quantity`}
                              className="w-8 h-8 flex items-center justify-center text-sm font-semibold text-[#173D30] hover:bg-[#173D30]/10 rounded-r-lg"
                            >
                              +
                            </button>
                          </div>

                          <button
                            type="button"
                            onClick={() => onRemoveItem(item.cartItemId)}
                            className="text-xs text-[#242821]/60 hover:text-[#C86F4A] transition-colors"
                          >
                            Remove
                          </button>
                        </div>
                      </li>
                    );
                  })}
                </ul>
              </>
            )}
          </div>

          {/* Footer Summary & Checkout Trigger */}
          {cart.length > 0 && (
            <div className="p-5 bg-white border-t border-[#173D30]/15 space-y-4">
              <div className="space-y-1">
                <div className="flex items-center justify-between text-base font-semibold text-[#242821]">
                  <span>Indicative Subtotal</span>
                  <span className="font-mono-num text-lg text-[#173D30]">
                    {RESTAURANT_CONFIG.currency.symbol}
                    {subtotal}
                  </span>
                </div>
                <p className="text-[11px] text-[#242821]/65 leading-relaxed">
                  *Prices shown are preliminary reference values. Final bill, taxes/packaging (if any) and availability are confirmed on WhatsApp by {RESTAURANT_CONFIG.brandName}.
                </p>
              </div>

              <button
                type="button"
                onClick={() => {
                  onClose();
                  onProceedToCheckout('order');
                }}
                className="w-full py-3 px-4 rounded-lg bg-[#173D30] hover:bg-[#C86F4A] text-[#FFF8ED] font-semibold text-sm flex items-center justify-center gap-2 transition-colors shadow-sm"
              >
                <MessageCircle className="w-4 h-4 text-[#D5AC65]" aria-hidden="true" />
                <span>Proceed to WhatsApp Checkout</span>
                <ArrowRight className="w-4 h-4" aria-hidden="true" />
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
