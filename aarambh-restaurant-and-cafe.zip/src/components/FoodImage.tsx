import React, { useState } from 'react';
import { UtensilsCrossed } from 'lucide-react';
import { RESTAURANT_CONFIG } from '../data/restaurantConfig';

interface FoodImageProps {
  src: string;
  alt: string;
  className?: string;
  containerClassName?: string;
  showIllustrativeNote?: boolean;
  captionOverlay?: string;
  priority?: boolean;
}

export const FoodImage: React.FC<FoodImageProps> = ({
  src,
  alt,
  className = 'w-full h-full object-cover',
  containerClassName = 'relative overflow-hidden bg-[#173D30]/10',
  showIllustrativeNote = true,
  captionOverlay,
  priority = false,
}) => {
  const [hasError, setHasError] = useState(false);
  const [isLoaded, setIsLoaded] = useState(false);

  return (
    <div className={containerClassName}>
      {!hasError ? (
        <>
          {!isLoaded && (
            <div
              className="absolute inset-0 bg-[#173D30]/10 animate-pulse flex items-center justify-center"
              aria-hidden="true"
            >
              <UtensilsCrossed className="w-7 h-7 text-[#173D30]/30" />
            </div>
          )}
          <img
            src={src}
            alt={alt}
            referrerPolicy="no-referrer"
            loading={priority ? 'eager' : 'lazy'}
            onLoad={() => setIsLoaded(true)}
            onError={() => setHasError(true)}
            className={`${className} transition-opacity duration-200 ${
              isLoaded ? 'opacity-100' : 'opacity-0'
            }`}
          />
        </>
      ) : (
        <div className="w-full h-full min-h-[180px] bg-gradient-to-br from-[#173D30] to-[#242821] text-[#FFF8ED] p-6 flex flex-col items-center justify-center text-center">
          <UtensilsCrossed className="w-8 h-8 text-[#D5AC65] mb-2" />
          <p className="font-serif-display text-base font-medium text-[#FFF8ED]">
            {RESTAURANT_CONFIG.shortName} Culinary Selection
          </p>
          <p className="text-xs text-[#FFF8ED]/75 mt-1 max-w-xs">{alt}</p>
        </div>
      )}

      {showIllustrativeNote && (
        <div className="absolute bottom-2 right-2 bg-[#242821]/75 backdrop-blur-xs text-[#FFF8ED]/90 px-2 py-0.5 rounded text-[11px] tracking-normal pointer-events-none">
          Illustrative representation
        </div>
      )}

      {captionOverlay && (
        <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent p-4 pt-10 text-[#FFF8ED]">
          <p className="text-xs text-[#FFF8ED]/90">{captionOverlay}</p>
        </div>
      )}
    </div>
  );
};
