import React, { useState } from 'react';
import { Plus, Check, SlidersHorizontal } from 'lucide-react';
import { MenuItem, MenuAddOn } from '../types/restaurant';
import { RESTAURANT_CONFIG } from '../data/restaurantConfig';
import { FoodImage } from './FoodImage';

interface DishCardProps {
  item: MenuItem;
  onAddToCart: (item: MenuItem, quantity: number, addOns: MenuAddOn[]) => void;
}

export const DishCard: React.FC<DishCardProps> = ({ item, onAddToCart }) => {
  const [quantity, setQuantity] = useState<number>(1);
  const [selectedAddOns, setSelectedAddOns] = useState<MenuAddOn[]>([]);
  const [showAddOns, setShowAddOns] = useState<boolean>(false);
  const [justAdded, setJustAdded] = useState<boolean>(false);

  const toggleAddOn = (addOn: MenuAddOn) => {
    setSelectedAddOns((prev) =>
      prev.some((a) => a.id === addOn.id)
        ? prev.filter((a) => a.id !== addOn.id)
        : [...prev, addOn]
    );
  };

  const addOnsTotal = selectedAddOns.reduce((sum, a) => sum + a.price, 0);
  const unitTotal = item.price + addOnsTotal;
  const lineTotal = unitTotal * quantity;

  const handleAdd = () => {
    if (!item.isAvailable) return;
    onAddToCart(item, quantity, selectedAddOns);
    setJustAdded(true);
    setTimeout(() => {
      setJustAdded(false);
    }, 1400);
  };

  return (
    <article className="bg-white/80 rounded-xl border border-[#173D30]/12 overflow-hidden flex flex-col justify-between transition-transform duration-200 hover:-translate-y-0.5 hover:shadow-md">
      <div>
        {/* Image Frame (4:3 ratio) */}
        <div className="relative aspect-4/3 w-full">
          <FoodImage
            src={item.image}
            alt={item.imageAlt}
            containerClassName="w-full h-full relative overflow-hidden bg-[#173D30]/10"
            showIllustrativeNote={item.isIllustrativeImage}
          />
        </div>

        {/* Content Body */}
        <div className="p-5">
          {/* Unboxed Metadata Line (Zero-Pill Discipline) */}
          <div className="flex flex-wrap items-center gap-1.5 text-xs text-[#242821]/65 mb-1.5">
            <span className="font-medium text-[#173D30]">
              {item.isVegetarian ? '100% Vegetarian' : 'Non-Veg'}
            </span>
            <span aria-hidden="true">·</span>
            <span>{item.categoryLabel}</span>
            {item.spiceLevel && (
              <>
                <span aria-hidden="true">·</span>
                <span>{item.spiceLevel}</span>
              </>
            )}
            {item.servingSize && (
              <>
                <span aria-hidden="true">·</span>
                <span>{item.servingSize}</span>
              </>
            )}
          </div>

          {/* Title & Price Row */}
          <div className="flex items-baseline justify-between gap-3">
            <h3 className="font-serif-display text-lg font-semibold text-[#242821] leading-snug">
              {item.name}
            </h3>
            <div className="text-right shrink-0">
              <span className="font-mono-num text-base font-semibold text-[#173D30]">
                {RESTAURANT_CONFIG.currency.symbol}
                {item.price}
              </span>
              {item.isIndicativePrice && (
                <span
                  title="Preliminary indicative reference price; confirmed on order"
                  className="block text-[11px] text-[#C86F4A] font-normal"
                >
                  Indicative*
                </span>
              )}
            </div>
          </div>

          {/* Description */}
          <p className="mt-2 text-sm text-[#242821]/75 line-clamp-3 leading-relaxed">
            {item.description}
          </p>

          {/* Optional Add-ons Toggle */}
          {item.addOns && item.addOns.length > 0 && (
            <div className="mt-3 pt-3 border-t border-[#173D30]/10">
              <button
                type="button"
                onClick={() => setShowAddOns(!showAddOns)}
                aria-expanded={showAddOns}
                className="inline-flex items-center gap-1.5 text-xs font-medium text-[#173D30] hover:text-[#C86F4A] transition-colors focus-visible:outline-2 focus-visible:outline-[#173D30] rounded"
              >
                <SlidersHorizontal className="w-3.5 h-3.5" aria-hidden="true" />
                <span>
                  {showAddOns
                    ? 'Hide Customization / Add-ons'
                    : `Customize / Add-ons (${item.addOns.length} options)`}
                </span>
              </button>

              {showAddOns && (
                <div className="mt-2.5 space-y-1.5 bg-[#FFF8ED] p-3 rounded-lg border border-[#173D30]/10">
                  <p className="text-[11px] text-[#242821]/65 mb-1">
                    Optional extras (indicative sample pricing):
                  </p>
                  {item.addOns.map((addOn) => {
                    const isSelected = selectedAddOns.some((a) => a.id === addOn.id);
                    return (
                      <label
                        key={addOn.id}
                        className="flex items-center justify-between gap-2 text-xs text-[#242821] cursor-pointer py-1 hover:text-[#173D30]"
                      >
                        <span className="flex items-center gap-2">
                          <input
                            type="checkbox"
                            checked={isSelected}
                            onChange={() => toggleAddOn(addOn)}
                            className="rounded border-[#173D30]/40 text-[#173D30] focus:ring-[#173D30]"
                          />
                          <span>{addOn.name}</span>
                        </span>
                        <span className="font-mono-num text-[#173D30] font-medium">
                          {addOn.price > 0
                            ? `+${RESTAURANT_CONFIG.currency.symbol}${addOn.price}`
                            : 'Included'}
                        </span>
                      </label>
                    );
                  })}
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Card Footer: Quantity Selector & Add to Cart Button */}
      <div className="px-5 pb-5 pt-2 flex items-center justify-between gap-3">
        {item.isAvailable ? (
          <>
            {/* Quantity Stepper */}
            <div
              className="inline-flex items-center border border-[#173D30]/20 rounded-lg bg-[#FFF8ED]"
              aria-label={`Quantity for ${item.name}`}
            >
              <button
                type="button"
                onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                aria-label={`Decrease quantity of ${item.name}`}
                className="w-9 h-10 flex items-center justify-center text-sm font-semibold text-[#173D30] hover:bg-[#173D30]/10 rounded-l-lg transition-colors focus-visible:outline-2 focus-visible:outline-[#173D30]"
              >
                −
              </button>
              <span className="w-8 text-center font-mono-num text-sm font-semibold text-[#242821]">
                {quantity}
              </span>
              <button
                type="button"
                onClick={() => setQuantity((q) => Math.min(20, q + 1))}
                aria-label={`Increase quantity of ${item.name}`}
                className="w-9 h-10 flex items-center justify-center text-sm font-semibold text-[#173D30] hover:bg-[#173D30]/10 rounded-r-lg transition-colors focus-visible:outline-2 focus-visible:outline-[#173D30]"
              >
                +
              </button>
            </div>

            {/* Add to Cart Button */}
            <button
              type="button"
              onClick={handleAdd}
              className={`flex-1 min-h-[40px] py-2 px-4 rounded-lg text-xs sm:text-sm font-semibold inline-flex items-center justify-center gap-1.5 transition-colors whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#173D30] ${
                justAdded
                  ? 'bg-[#173D30] text-[#D5AC65]'
                  : 'bg-[#173D30] text-[#FFF8ED] hover:bg-[#C86F4A]'
              }`}
            >
              {justAdded ? (
                <>
                  <Check className="w-4 h-4 shrink-0" aria-hidden="true" />
                  <span>Added to Order</span>
                </>
              ) : (
                <>
                  <Plus className="w-4 h-4 shrink-0" aria-hidden="true" />
                  <span>
                    Add · {RESTAURANT_CONFIG.currency.symbol}
                    <span className="font-mono-num">{lineTotal}</span>
                  </span>
                </>
              )}
            </button>
          </>
        ) : (
          <div className="w-full py-2 px-4 rounded-lg bg-[#242821]/10 text-[#242821]/60 text-xs font-medium text-center">
            Currently Unavailable — Ask on WhatsApp
          </div>
        )}
      </div>
    </article>
  );
};
