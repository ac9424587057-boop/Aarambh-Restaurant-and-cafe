import {
  RestaurantConfig,
  MenuItem,
  GalleryPhoto,
  MenuCategoryId,
} from '../types/restaurant';

/**
 * CENTRALIZED CONFIGURATION & MENU DATA MODULE
 * ----------------------------------------------------------------------------
 * Edit this file to update business details, phone numbers, opening hours,
 * menu dishes, prices, availability, or gallery photos before or after launch.
 * Can also be replaced with an API/CMS fetch call in `src/services/` in the future.
 */

export const IMAGES = {
  HERO_SPREAD: '/src/assets/images/hero_indian_dining_table_1791785651882.jpg',
  NORTH_INDIAN: '/src/assets/images/north_indian_paneer_thali_1791785666161.jpg',
  INDO_CHINESE: '/src/assets/images/indo_chinese_starters_platter_1791785677235.jpg',
  DESSERTS_CAFE: '/src/assets/images/gulab_jamun_desserts_cafe_1791785705334.jpg',
};

export const RESTAURANT_CONFIG: RestaurantConfig = {
  brandName: 'Aarambh Restaurant and Cafe',
  shortName: 'Aarambh',
  tagline: 'Good Food. Great Moments.',
  supportingIntro:
    'Welcome to Aarambh Restaurant and Cafe in Thakur Pura, Shivpuri. From comforting North Indian curries and crisp Indo-Chinese starters to freshly brewed cafe beverages and quick bites, we bring families, students, couples and friends together around warm, freshly prepared vegetarian food.',
  location: {
    area: 'Thakur Pura',
    city: 'Shivpuri',
    state: 'Madhya Pradesh',
    postalCode: '473638',
    country: 'India',
    landmarkReference: 'In front of Katha Mill, near Panchmukhi Hanuman Temple',
    fullAddress:
      'In front of Katha Mill, near Panchmukhi Hanuman Temple, Thakur Pura, Shivpuri, Madhya Pradesh – 473638, India',
    googleMapsUrl: 'https://maps.app.goo.gl/3vGqdbi11E4f6XxP9',
  },
  contact: {
    phoneDisplay: '+91 78039 29746',
    phoneDial: '+917803929746',
    whatsappNumber: '917803929746',
  },
  openingHours: {
    listedHours: '12:00 PM – 11:30 PM',
    statusNote: 'Listed hours: 12:00 PM – 11:30 PM (Subject to confirmation on holidays; call to verify)',
    isConfirmedForPublishing: false,
    scheduleSummary: 'Monday – Sunday: 12:00 PM – 11:30 PM (Listed schedule; please confirm before visiting late)',
  },
  currency: {
    code: 'INR',
    symbol: '₹',
  },
  pricingDisclaimer: {
    shortLabel: 'Indicative Price',
    bannerText:
      'Note on Menu Pricing: Listed prices (such as Veg Fried Rice at ₹160, Paneer 65 at ₹270, and North Indian dishes around ₹140–₹290) are preliminary reference/indicative prices. Final prices and dish availability are confirmed directly by the restaurant when you place your order request.',
    checkoutNotice:
      'Submitting through WhatsApp sends an order enquiry directly to Aarambh Restaurant and Cafe. It does not guarantee immediate acceptance, online payment processing, or live delivery tracking until confirmed by our staff.',
  },
  imageDisclaimer:
    'Food and dining photographs shown across this website are illustrative representations of our cuisine categories and are not actual photographs of the restaurant premises.',
  targetCustomers: [
    'Families seeking relaxed North Indian lunches and dinners',
    'Students & friends catching up over cafe snacks, Maggi, pizza and cold coffee',
    'Couples looking for a warm, comfortable dining atmosphere in Shivpuri',
    'Local residents & takeaway customers in Thakur Pura and surrounding areas',
  ],
  // Kept empty until real verified customer testimonials are provided by the business owner.
  reviews: [],
};

export const MENU_CATEGORIES: {
  id: MenuCategoryId;
  label: string;
  shortDescription: string;
  dishCount: number;
  highlightImage: string;
}[] = [
  {
    id: 'all',
    label: 'All Dishes',
    shortDescription: 'Complete selection of North Indian mains, starters, fast food, cafe drinks & desserts',
    dishCount: 23,
    highlightImage: IMAGES.HERO_SPREAD,
  },
  {
    id: 'north-indian',
    label: 'North Indian',
    shortDescription: 'Rich paneer gravies, slow-simmered dal, kaju curry & complete comforting thalis',
    dishCount: 5,
    highlightImage: IMAGES.NORTH_INDIAN,
  },
  {
    id: 'chinese-starters',
    label: 'Chinese & Starters',
    shortDescription: 'Wok-tossed Chilli Paneer, crispy Paneer 65, Honey Chilli Potato, fried rice & noodles',
    dishCount: 5,
    highlightImage: IMAGES.INDO_CHINESE,
  },
  {
    id: 'fast-food',
    label: 'Fast Food',
    shortDescription: 'Oven-baked pizzas, creamy pasta, grilled sandwiches, burgers, Maggi & garlic bread',
    dishCount: 7,
    highlightImage: IMAGES.HERO_SPREAD,
  },
  {
    id: 'cafe-beverages',
    label: 'Cafe & Beverages',
    shortDescription: 'Chilled cold coffee, thick chocolate shakes, mint mojitos & traditional sweet lassi',
    dishCount: 4,
    highlightImage: IMAGES.HERO_SPREAD,
  },
  {
    id: 'desserts',
    label: 'Desserts',
    shortDescription: 'Warm cardamom-kissed Gulab Jamun and classic creamy ice cream scoops',
    dishCount: 2,
    highlightImage: IMAGES.DESSERTS_CAFE,
  },
];

export const MENU_ITEMS: MenuItem[] = [
  // ==========================================
  // A. NORTH INDIAN (Approx ₹140–₹290 indicative)
  // ==========================================
  {
    id: 'ni-paneer-butter-masala',
    name: 'Paneer Butter Masala',
    description:
      'Soft malai paneer cubes simmered in a velvety tomato, butter and cashew gravy finished with aromatic kasuri methi and fresh cream.',
    price: 240,
    isIndicativePrice: true,
    priceNote: 'Indicative reference (~₹140–₹290 range)',
    category: 'north-indian',
    categoryLabel: 'North Indian',
    isVegetarian: true,
    isAvailable: true,
    isFeatured: true,
    spiceLevel: 'Medium',
    servingSize: 'Serves 2',
    image: IMAGES.NORTH_INDIAN,
    imageAlt: 'Illustrative photo of Paneer Butter Masala served in a traditional bowl',
    isIllustrativeImage: true,
    addOns: [
      { id: 'ao-butter-naan', name: 'Butter Naan (1 pc)', price: 45, isSamplePrice: true },
      { id: 'ao-tandoori-roti', name: 'Butter Tandoori Roti (1 pc)', price: 25, isSamplePrice: true },
      { id: 'ao-jeera-rice', name: 'Half Jeera Rice', price: 90, isSamplePrice: true },
    ],
  },
  {
    id: 'ni-matar-paneer',
    name: 'Matar Paneer',
    description:
      'Homestyle preparation of tender green peas and fresh paneer cooked in a spiced onion-tomato masala with fresh coriander.',
    price: 210,
    isIndicativePrice: true,
    priceNote: 'Indicative reference (~₹140–₹290 range)',
    category: 'north-indian',
    categoryLabel: 'North Indian',
    isVegetarian: true,
    isAvailable: true,
    isFeatured: false,
    spiceLevel: 'Medium',
    servingSize: 'Serves 2',
    image: IMAGES.NORTH_INDIAN,
    imageAlt: 'Illustrative photo of homestyle North Indian Matar Paneer',
    isIllustrativeImage: true,
    addOns: [
      { id: 'ao-butter-naan', name: 'Butter Naan (1 pc)', price: 45, isSamplePrice: true },
      { id: 'ao-tandoori-roti', name: 'Butter Tandoori Roti (1 pc)', price: 25, isSamplePrice: true },
    ],
  },
  {
    id: 'ni-shahi-paneer',
    name: 'Shahi Paneer',
    description:
      'Royal Mughlai-inspired curry featuring cottage cheese in a rich, mildly sweet cashew and cream gravy infused with green cardamom.',
    price: 250,
    isIndicativePrice: true,
    priceNote: 'Indicative reference (~₹140–₹290 range)',
    category: 'north-indian',
    categoryLabel: 'North Indian',
    isVegetarian: true,
    isAvailable: true,
    isFeatured: false,
    spiceLevel: 'Mild',
    servingSize: 'Serves 2',
    image: IMAGES.NORTH_INDIAN,
    imageAlt: 'Illustrative photo of creamy Shahi Paneer curry',
    isIllustrativeImage: true,
    addOns: [
      { id: 'ao-garlic-naan', name: 'Garlic Naan (1 pc)', price: 55, isSamplePrice: true },
      { id: 'ao-butter-naan', name: 'Butter Naan (1 pc)', price: 45, isSamplePrice: true },
    ],
  },
  {
    id: 'ni-kaju-curry',
    name: 'Kaju Curry',
    description:
      'Whole roasted golden cashews cooked in a rich, mildly spiced khoya and tomato-cashew masala gravy.',
    price: 290,
    isIndicativePrice: true,
    priceNote: 'Indicative reference (~₹140–₹290 range)',
    category: 'north-indian',
    categoryLabel: 'North Indian',
    isVegetarian: true,
    isAvailable: true,
    isFeatured: true,
    spiceLevel: 'Medium',
    servingSize: 'Serves 2',
    image: IMAGES.NORTH_INDIAN,
    imageAlt: 'Illustrative photo of rich roasted Kaju Curry',
    isIllustrativeImage: true,
    addOns: [
      { id: 'ao-butter-naan', name: 'Butter Naan (1 pc)', price: 45, isSamplePrice: true },
      { id: 'ao-lachha-paratha', name: 'Lachha Paratha (1 pc)', price: 50, isSamplePrice: true },
    ],
  },
  {
    id: 'ni-dal-and-thali',
    name: 'Dal Tadka & Special Veg Thali',
    description:
      'Yellow dal tempered with pure ghee, cumin, garlic and red chillies, or upgrade to a complete North Indian Thali with paneer, dal, seasonal veg, rice, breads and sweet.',
    price: 140,
    isIndicativePrice: true,
    priceNote: 'Indicative reference (~₹140 Dal / ₹240 Thali)',
    category: 'north-indian',
    categoryLabel: 'North Indian',
    isVegetarian: true,
    isAvailable: true,
    isFeatured: true,
    spiceLevel: 'Medium',
    servingSize: '1 Person / Shareable',
    image: IMAGES.NORTH_INDIAN,
    imageAlt: 'Illustrative photo of North Indian Dal and complete Vegetarian Thali platter',
    isIllustrativeImage: true,
    addOns: [
      { id: 'ao-upgrade-thali', name: 'Upgrade to Complete Special Thali', price: 100, isSamplePrice: true },
      { id: 'ao-extra-roti', name: 'Extra Butter Roti (2 pcs)', price: 45, isSamplePrice: true },
      { id: 'ao-papad-salad', name: 'Roasted Masala Papad', price: 30, isSamplePrice: true },
    ],
  },

  // ==========================================
  // B. CHINESE AND STARTERS
  // ==========================================
  {
    id: 'cs-paneer-65',
    name: 'Paneer 65',
    description:
      'Crispy batter-fried paneer cubes tempered with curry leaves, green chillies, garlic, mustard seeds and a tangy South-meets-Indo-Chinese spice glaze.',
    price: 270,
    isIndicativePrice: true,
    priceNote: 'Listed reference price: ₹270 (Confirm on order)',
    category: 'chinese-starters',
    categoryLabel: 'Chinese & Starters',
    isVegetarian: true,
    isAvailable: true,
    isFeatured: true,
    spiceLevel: 'Spicy',
    servingSize: 'Starter Portion',
    image: IMAGES.INDO_CHINESE,
    imageAlt: 'Illustrative photo of crispy Paneer 65 garnished with curry leaves and sesame',
    isIllustrativeImage: true,
    addOns: [
      { id: 'ao-extra-schezwan', name: 'Schezwan Dip on Side', price: 25, isSamplePrice: true },
    ],
  },
  {
    id: 'cs-veg-fried-rice',
    name: 'Veg Fried Rice',
    description:
      'Fragrant long-grain rice wok-tossed on high flame with finely diced carrots, French beans, cabbage, spring onions and soy-garlic seasoning.',
    price: 160,
    isIndicativePrice: true,
    priceNote: 'Listed reference price: ₹160 (Confirm on order)',
    category: 'chinese-starters',
    categoryLabel: 'Chinese & Starters',
    isVegetarian: true,
    isAvailable: true,
    isFeatured: true,
    spiceLevel: 'Mild',
    servingSize: 'Full Portion',
    image: IMAGES.INDO_CHINESE,
    imageAlt: 'Illustrative photo of wok-tossed Veg Fried Rice with fresh vegetables',
    isIllustrativeImage: true,
    addOns: [
      { id: 'ao-schezwan-style', name: 'Make it Schezwan Style', price: 30, isSamplePrice: true },
      { id: 'ao-paneer-top', name: 'Add Fried Paneer Cubes', price: 50, isSamplePrice: true },
    ],
  },
  {
    id: 'cs-chilli-paneer',
    name: 'Chilli Paneer (Dry / Gravy)',
    description:
      'Golden-seared cottage cheese tossed with crunchy bell peppers, onions, green chillies and dark soy-chilli sauce.',
    price: 240,
    isIndicativePrice: true,
    priceNote: 'Indicative sample price',
    category: 'chinese-starters',
    categoryLabel: 'Chinese & Starters',
    isVegetarian: true,
    isAvailable: true,
    isFeatured: false,
    spiceLevel: 'Spicy',
    servingSize: 'Starter / Main',
    image: IMAGES.HERO_SPREAD,
    imageAlt: 'Illustrative photo of sizzling Chilli Paneer with bell peppers',
    isIllustrativeImage: true,
    addOns: [
      { id: 'ao-gravy-option', name: 'Prepare as Semi-Gravy', price: 0, isSamplePrice: true },
      { id: 'ao-extra-capsicum', name: 'Extra Roasted Garlic & Peppers', price: 25, isSamplePrice: true },
    ],
  },
  {
    id: 'cs-honey-chilli-potato',
    name: 'Honey Chilli Potato',
    description:
      'Crisp potato fingers glazed in a sweet and fiery honey-chilli sauce, finished with toasted white sesame seeds and spring onion greens.',
    price: 180,
    isIndicativePrice: true,
    priceNote: 'Indicative sample price',
    category: 'chinese-starters',
    categoryLabel: 'Chinese & Starters',
    isVegetarian: true,
    isAvailable: true,
    isFeatured: false,
    spiceLevel: 'Medium',
    servingSize: 'Shareable Starter',
    image: IMAGES.INDO_CHINESE,
    imageAlt: 'Illustrative photo of crispy Honey Chilli Potato with sesame seeds',
    isIllustrativeImage: true,
  },
  {
    id: 'cs-soup-and-noodles',
    name: 'Hot Soup & Veg Hakka Noodles',
    description:
      'Street-style wok-tossed Veg Hakka Noodles with julienned vegetables, or pair with a piping hot bowl of Manchow / Sweet Corn Veg Soup.',
    price: 150,
    isIndicativePrice: true,
    priceNote: 'Indicative sample price',
    category: 'chinese-starters',
    categoryLabel: 'Chinese & Starters',
    isVegetarian: true,
    isAvailable: true,
    isFeatured: false,
    spiceLevel: 'Medium',
    servingSize: '1–2 Persons',
    image: IMAGES.INDO_CHINESE,
    imageAlt: 'Illustrative photo of Indo-Chinese noodles and soup',
    isIllustrativeImage: true,
    addOns: [
      { id: 'ao-add-manchow-soup', name: 'Add Veg Manchow Soup Bowl', price: 95, isSamplePrice: true },
      { id: 'ao-chilli-garlic-noodles', name: 'Upgrade to Chilli Garlic Noodles', price: 25, isSamplePrice: true },
    ],
  },

  // ==========================================
  // C. FAST FOOD
  // ==========================================
  {
    id: 'ff-pizza',
    name: 'Farmhouse Veg Pizza',
    description:
      'Freshly baked crust topped with tangy herbed tomato sauce, stretchy mozzarella cheese, crisp capsicum, sweet corn, onions and tomatoes.',
    price: 210,
    isIndicativePrice: true,
    priceNote: 'Indicative sample price',
    category: 'fast-food',
    categoryLabel: 'Fast Food',
    isVegetarian: true,
    isAvailable: true,
    isFeatured: false,
    spiceLevel: 'Mild',
    servingSize: 'Regular (8 inch)',
    image: IMAGES.HERO_SPREAD,
    imageAlt: 'Illustrative photo of vegetarian pizza with bell peppers and cheese',
    isIllustrativeImage: true,
    addOns: [
      { id: 'ao-extra-cheese-pizza', name: 'Extra Mozzarella Cheese Burst', price: 50, isSamplePrice: true },
      { id: 'ao-paneer-tikka-top', name: 'Spiced Paneer Topping', price: 45, isSamplePrice: true },
    ],
  },
  {
    id: 'ff-pasta',
    name: 'Creamy Café Pasta (White / Red Sauce)',
    description:
      'Penne pasta tossed in your choice of rich cheesy béchamel white sauce or tangy arrabbiata tomato sauce with sweet corn, olives and herbs.',
    price: 170,
    isIndicativePrice: true,
    priceNote: 'Indicative sample price',
    category: 'fast-food',
    categoryLabel: 'Fast Food',
    isVegetarian: true,
    isAvailable: true,
    isFeatured: false,
    spiceLevel: 'Mild',
    servingSize: '1 Bowl (with Garlic Bread)',
    image: IMAGES.HERO_SPREAD,
    imageAlt: 'Illustrative photo of creamy cafe pasta bowl',
    isIllustrativeImage: true,
    addOns: [
      { id: 'ao-mixed-pink-sauce', name: 'Mixed Pink Sauce Preparation', price: 20, isSamplePrice: true },
      { id: 'ao-extra-cheese-pasta', name: 'Extra Grated Cheese', price: 30, isSamplePrice: true },
    ],
  },
  {
    id: 'ff-veg-burger',
    name: 'Crispy Veg Cheese Burger',
    description:
      'Golden-fried spiced vegetable patty layered with fresh lettuce, tomato, onion rings, creamy chipotle mayo and a slice of cheddar in a toasted sesame bun.',
    price: 110,
    isIndicativePrice: true,
    priceNote: 'Indicative sample price',
    category: 'fast-food',
    categoryLabel: 'Fast Food',
    isVegetarian: true,
    isAvailable: true,
    isFeatured: false,
    spiceLevel: 'Medium',
    servingSize: '1 Burger',
    image: IMAGES.HERO_SPREAD,
    imageAlt: 'Illustrative photo of crispy vegetarian burger',
    isIllustrativeImage: true,
    addOns: [
      { id: 'ao-burger-fries-combo', name: 'Add Side Salted Fries', price: 65, isSamplePrice: true },
      { id: 'ao-double-cheese', name: 'Extra Cheese Slice', price: 25, isSamplePrice: true },
    ],
  },
  {
    id: 'ff-sandwich',
    name: 'Bombay Masala & Cheese Grilled Sandwich',
    description:
      'Triple-layer jumbo bread grilled golden with green mint chutney, spiced potato-pea filling, cucumber, tomatoes and melted cheese.',
    price: 130,
    isIndicativePrice: true,
    priceNote: 'Indicative sample price',
    category: 'fast-food',
    categoryLabel: 'Fast Food',
    isVegetarian: true,
    isAvailable: true,
    isFeatured: false,
    spiceLevel: 'Medium',
    servingSize: '4 Triangles',
    image: IMAGES.HERO_SPREAD,
    imageAlt: 'Illustrative photo of grilled vegetarian sandwich',
    isIllustrativeImage: true,
    addOns: [
      { id: 'ao-paneer-stuffing', name: 'Add Tandoori Paneer Stuffing', price: 40, isSamplePrice: true },
    ],
  },
  {
    id: 'ff-french-fries',
    name: 'Crispy Golden French Fries',
    description:
      'Crisp golden potato fries lightly seasoned with rock salt or fiery peri-peri spice mix, served with tomato ketchup and cheesy dip.',
    price: 110,
    isIndicativePrice: true,
    priceNote: 'Indicative sample price',
    category: 'fast-food',
    categoryLabel: 'Fast Food',
    isVegetarian: true,
    isAvailable: true,
    isFeatured: false,
    spiceLevel: 'Mild',
    servingSize: 'Shareable Basket',
    image: IMAGES.INDO_CHINESE,
    imageAlt: 'Illustrative photo of crispy golden French fries',
    isIllustrativeImage: true,
    addOns: [
      { id: 'ao-peri-peri-masala', name: 'Peri-Peri Spice Dust', price: 20, isSamplePrice: true },
      { id: 'ao-cheesy-jalapeno-dip', name: 'Cheesy Dip', price: 30, isSamplePrice: true },
    ],
  },
  {
    id: 'ff-maggi',
    name: 'Café Special Vegetable Masala Maggi',
    description:
      'Everyone’s favourite comfort noodles cooked with sautéed onions, green peas, capsicum, tomatoes and signature masala.',
    price: 90,
    isIndicativePrice: true,
    priceNote: 'Indicative sample price',
    category: 'fast-food',
    categoryLabel: 'Fast Food',
    isVegetarian: true,
    isAvailable: true,
    isFeatured: false,
    spiceLevel: 'Medium',
    servingSize: '1 Bowl',
    image: IMAGES.INDO_CHINESE,
    imageAlt: 'Illustrative photo of hot vegetable masala Maggi noodles',
    isIllustrativeImage: true,
    addOns: [
      { id: 'ao-cheese-maggi', name: 'Melted Cheese Topping', price: 30, isSamplePrice: true },
      { id: 'ao-butter-tadka', name: 'Amul Butter Tadka', price: 20, isSamplePrice: true },
    ],
  },
  {
    id: 'ff-garlic-bread',
    name: 'Cheesy Herb Garlic Bread',
    description:
      'Oven-toasted baguette slices brushed with roasted garlic butter, oregano, chilli flakes and bubbling mozzarella cheese.',
    price: 130,
    isIndicativePrice: true,
    priceNote: 'Indicative sample price',
    category: 'fast-food',
    categoryLabel: 'Fast Food',
    isVegetarian: true,
    isAvailable: true,
    isFeatured: false,
    spiceLevel: 'Mild',
    servingSize: '4 Pieces',
    image: IMAGES.HERO_SPREAD,
    imageAlt: 'Illustrative photo of toasted cheesy herb garlic bread',
    isIllustrativeImage: true,
    addOns: [
      { id: 'ao-sweet-corn-jalapeno', name: 'Sweet Corn & Jalapeño Topping', price: 25, isSamplePrice: true },
    ],
  },

  // ==========================================
  // D. CAFE AND BEVERAGES
  // ==========================================
  {
    id: 'cb-cold-coffee',
    name: 'Signature Thick Cold Coffee',
    description:
      'Rich espresso-style coffee blended with chilled full-cream milk, cocoa dust and chocolate drizzle for a refreshing cafe pick-me-up.',
    price: 120,
    isIndicativePrice: true,
    priceNote: 'Indicative sample price',
    category: 'cafe-beverages',
    categoryLabel: 'Cafe & Beverages',
    isVegetarian: true,
    isAvailable: true,
    isFeatured: true,
    spiceLevel: 'Sweet',
    servingSize: '350 ml Glass',
    image: IMAGES.HERO_SPREAD,
    imageAlt: 'Illustrative photo of frosted glass of thick Cold Coffee',
    isIllustrativeImage: true,
    addOns: [
      { id: 'ao-vanilla-scoop', name: 'Top with Vanilla Ice Cream Scoop', price: 35, isSamplePrice: true },
    ],
  },
  {
    id: 'cb-chocolate-shake',
    name: 'Belgian Chocolate Thick Shake',
    description:
      'Indulgent milkshake spun with rich dark chocolate ganache, chilled milk, chocolate chips and whipped cream.',
    price: 140,
    isIndicativePrice: true,
    priceNote: 'Indicative sample price',
    category: 'cafe-beverages',
    categoryLabel: 'Cafe & Beverages',
    isVegetarian: true,
    isAvailable: true,
    isFeatured: false,
    spiceLevel: 'Sweet',
    servingSize: '350 ml Glass',
    image: IMAGES.HERO_SPREAD,
    imageAlt: 'Illustrative photo of rich Chocolate Shake',
    isIllustrativeImage: true,
    addOns: [
      { id: 'ao-oreo-crumble', name: 'Add Oreo Cookie Crumble', price: 25, isSamplePrice: true },
    ],
  },
  {
    id: 'cb-mojito',
    name: 'Virgin Mint Lime Mojito',
    description:
      'Sparkling refresher muddled with fresh garden mint leaves, lemon wedges, rock salt and crushed ice.',
    price: 110,
    isIndicativePrice: true,
    priceNote: 'Indicative sample price',
    category: 'cafe-beverages',
    categoryLabel: 'Cafe & Beverages',
    isVegetarian: true,
    isAvailable: true,
    isFeatured: false,
    spiceLevel: 'Refreshing',
    servingSize: '350 ml Glass',
    image: IMAGES.HERO_SPREAD,
    imageAlt: 'Illustrative photo of refreshing mint lime mojito',
    isIllustrativeImage: true,
  },
  {
    id: 'cb-lassi',
    name: 'Traditional Punjabi Sweet Lassi',
    description:
      'Thick, hand-churned yogurt lassi lightly scented with rose water and green cardamom, topped with malai and chopped pistachios.',
    price: 95,
    isIndicativePrice: true,
    priceNote: 'Indicative sample price',
    category: 'cafe-beverages',
    categoryLabel: 'Cafe & Beverages',
    isVegetarian: true,
    isAvailable: true,
    isFeatured: false,
    spiceLevel: 'Sweet',
    servingSize: 'Tall Kulhad / Glass',
    image: IMAGES.NORTH_INDIAN,
    imageAlt: 'Illustrative photo of chilled sweet Punjabi Lassi',
    isIllustrativeImage: true,
  },

  // ==========================================
  // E. DESSERTS
  // ==========================================
  {
    id: 'ds-gulab-jamun',
    name: 'Warm Kesar Gulab Jamun (2 Pcs)',
    description:
      'Melt-in-the-mouth khoya dumplings soaked in warm saffron and cardamom sugar syrup, garnished with pistachio slivers.',
    price: 80,
    isIndicativePrice: true,
    priceNote: 'Indicative sample price',
    category: 'desserts',
    categoryLabel: 'Desserts',
    isVegetarian: true,
    isAvailable: true,
    isFeatured: false,
    spiceLevel: 'Sweet',
    servingSize: '2 Pieces',
    image: IMAGES.DESSERTS_CAFE,
    imageAlt: 'Illustrative photo of warm Gulab Jamun garnished with pistachios',
    isIllustrativeImage: true,
    addOns: [
      { id: 'ao-jamun-icecream', name: 'Add Vanilla Ice Cream Scoop (Gadbad Style)', price: 40, isSamplePrice: true },
    ],
  },
  {
    id: 'ds-ice-cream',
    name: 'Classic Creamery Ice Cream (Double Scoop)',
    description:
      'Choice of creamy Vanilla Bean, Rich Chocolate, Butterscotch Crunch or Strawberry served chilled in a dessert bowl.',
    price: 90,
    isIndicativePrice: true,
    priceNote: 'Indicative sample price',
    category: 'desserts',
    categoryLabel: 'Desserts',
    isVegetarian: true,
    isAvailable: true,
    isFeatured: false,
    spiceLevel: 'Sweet',
    servingSize: '2 Scoops',
    image: IMAGES.DESSERTS_CAFE,
    imageAlt: 'Illustrative photo of creamy ice cream scoop with nuts',
    isIllustrativeImage: true,
    addOns: [
      { id: 'ao-hot-fudge', name: 'Warm Chocolate Fudge Drizzle', price: 20, isSamplePrice: true },
    ],
  },
];

export const GALLERY_PHOTOS: GalleryPhoto[] = [
  {
    id: 'gal-1',
    title: 'North Indian Dining Spread & Cold Coffee',
    category: 'Dining Atmosphere',
    caption:
      'Illustrative representation of our signature table spread—combining Paneer Butter Masala, tandoori naan, sizzling Chilli Paneer and chilled cafe beverages.',
    imageUrl: IMAGES.HERO_SPREAD,
    altText: 'Illustrative dining table spread with Paneer Butter Masala, naan, Chilli Paneer and cold coffee',
    isIllustrative: true,
    aspectRatio: '16:9',
  },
  {
    id: 'gal-2',
    title: 'Homestyle Paneer Gravies & Traditional Thali',
    category: 'North Indian',
    caption:
      'Illustrative culinary presentation of rich North Indian paneer gravies, slow-cooked dal, jeera rice and garlic naan.',
    imageUrl: IMAGES.NORTH_INDIAN,
    altText: 'Illustrative North Indian thali platter with paneer gravy, dal, rice and naan',
    isIllustrative: true,
    aspectRatio: '4:3',
  },
  {
    id: 'gal-3',
    title: 'Crispy Paneer 65, Honey Chilli Potato & Fried Rice',
    category: 'Indo-Chinese',
    caption:
      'Illustrative platter of our popular Indo-Chinese starters—Paneer 65, sesame-glazed Honey Chilli Potato and wok-tossed Veg Fried Rice.',
    imageUrl: IMAGES.INDO_CHINESE,
    altText: 'Illustrative platter of Paneer 65, Honey Chilli Potato and Veg Fried Rice',
    isIllustrative: true,
    aspectRatio: '4:3',
  },
  {
    id: 'gal-4',
    title: 'Warm Saffron Gulab Jamun & Vanilla Bean Ice Cream',
    category: 'Desserts & Beverages',
    caption:
      'Illustrative dessert pairing of warm pistachio-crusted Gulab Jamun alongside a scoop of creamy vanilla ice cream.',
    imageUrl: IMAGES.DESSERTS_CAFE,
    altText: 'Illustrative bowl of warm Gulab Jamun with vanilla ice cream and pistachios',
    isIllustrative: true,
    aspectRatio: '4:3',
  },
];

/**
 * Helper to generate a clean, URL-encoded WhatsApp order link
 */
export function buildWhatsAppOrderUrl(params: {
  itemsSummary: string;
  subtotal: number;
  customerName: string;
  phoneNumber: string;
  orderPreference: 'pickup' | 'delivery';
  address: string;
  notes: string;
}): string {
  const {
    itemsSummary,
    subtotal,
    customerName,
    phoneNumber,
    orderPreference,
    address,
    notes,
  } = params;

  const formattedPreference =
    orderPreference === 'delivery' ? 'Delivery' : 'Self Pickup at Restaurant';
  const formattedAddress =
    orderPreference === 'delivery'
      ? address.trim()
      : 'Pickup at Aarambh Restaurant and Cafe (Thakur Pura, Shivpuri)';
  const formattedNotes = notes.trim() ? notes.trim() : 'None';

  const message = `Hello ${RESTAURANT_CONFIG.brandName}, I would like to place an order. Items: ${itemsSummary}. Subtotal: ₹${subtotal} (indicative). Name: ${customerName.trim()}. Phone: ${phoneNumber.trim()}. Order preference: ${formattedPreference}. Address: ${formattedAddress}. Notes: ${formattedNotes}. Please confirm availability and the final bill.`;

  return `https://wa.me/${RESTAURANT_CONFIG.contact.whatsappNumber}?text=${encodeURIComponent(message)}`;
}

/**
 * Helper to generate a general WhatsApp enquiry link
 */
export function buildWhatsAppEnquiryUrl(customText?: string): string {
  const defaultMessage =
    customText ||
    `Hello ${RESTAURANT_CONFIG.brandName}, I would like to enquire about today's menu availability and table/takeaway options at Thakur Pura, Shivpuri.`;
  return `https://wa.me/${RESTAURANT_CONFIG.contact.whatsappNumber}?text=${encodeURIComponent(defaultMessage)}`;
}
