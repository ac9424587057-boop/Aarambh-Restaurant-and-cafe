import React, { useState } from 'react';
import {
  ShoppingBag,
  Trash2,
  MessageCircle,
  AlertCircle,
  CheckCircle2,
  Plus,
  Utensils,
  Phone,
} from 'lucide-react';
import {
  CartItem,
  CheckoutFormData,
  MenuItem,
  MenuAddOn,
  PageId,
} from '../types/restaurant';
import {
  RESTAURANT_CONFIG,
  MENU_ITEMS,
  buildWhatsAppOrderUrl,
} from '../data/restaurantConfig';

interface OrderPageProps {
  cart: CartItem[];
  onUpdateQuantity: (cartItemId: string, delta: number) => void;
  onRemoveItem: (cartItemId: string) => void;
  onClearCart: () => void;
  onAddToCart: (item: MenuItem, quantity: number, addOns: MenuAddOn[]) => void;
  subtotal: number;
  onNavigate: (page: PageId) => void;
}

export const OrderPage: React.FC<OrderPageProps> = ({
  cart,
  onUpdateQuantity,
  onRemoveItem,
  onClearCart,
  onAddToCart,
  subtotal,
  onNavigate,
}) => {
  const [formData, setFormData] = useState<CheckoutFormData>({
    customerName: '',
    phoneNumber: '',
    orderPreference: 'pickup',
    deliveryAddress: '',
    orderNotes: '',
  });

  const [formError, setFormError] = useState<string | null>(null);
  const [generatedWhatsAppUrl, setGeneratedWhatsAppUrl] = useState<
    string | null
  >(null);

  // Format itemized string for WhatsApp
  const buildItemsSummaryString = (): string => {
    return cart
      .map((item) => {
        const addOnsStr =
          item.selectedAddOns.length > 0
            ? ` (with ${item.selectedAddOns.map((a) => a.name).join(', ')})`
            : '';
        const addOnCost = item.selectedAddOns.reduce(
          (sum, a) => sum + a.price,
          0
        );
        const lineSubtotal = (item.menuItem.price + addOnCost) * item.quantity;
        return `${item.quantity}x ${item.menuItem.name}${addOnsStr} [₹${lineSubtotal}]`;
      })
      .join('; ');
  };

  const validateCheckout = (): string | null => {
    if (cart.length === 0) {
      return 'Your cart is empty. Please add at least one dish before placing an order.';
    }
    if (formData.customerName.trim().length < 2) {
      return 'Please enter your full name (at least 2 characters).';
    }
    const cleanPhone = formData.phoneNumber.replace(/[\s\-+]/g, '');
    if (!/^[0-9]{10,13}$/.test(cleanPhone)) {
      return 'Please enter a valid 10-digit mobile number so the restaurant can confirm your order.';
    }
    if (
      formData.orderPreference === 'delivery' &&
      formData.deliveryAddress.trim().length < 8
    ) {
      return 'Please enter your complete delivery address and landmark in Shivpuri (or select Self Pickup).';
    }
    return null;
  };

  const handlePlaceOrder = (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);

    const validationError = validateCheckout();
    if (validationError) {
      setFormError(validationError);
      return;
    }

    const url = buildWhatsAppOrderUrl({
      itemsSummary: buildItemsSummaryString(),
      subtotal,
      customerName: formData.customerName,
      phoneNumber: formData.phoneNumber,
      orderPreference: formData.orderPreference,
      address: formData.deliveryAddress,
      notes: formData.orderNotes,
    });

    setGeneratedWhatsAppUrl(url);
  };

  const quickAddDishes = MENU_ITEMS.slice(0, 6);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-14 space-y-10">
      {/* Page Header */}
      <div className="border-b border-[#173D30]/15 pb-8 space-y-2 max-w-3xl">
        <p className="text-xs font-semibold text-[#C86F4A]">
          Direct WhatsApp Order Request · {RESTAURANT_CONFIG.contact.phoneDisplay}
        </p>
        <h1 className="font-serif-display text-3xl sm:text-4xl font-bold text-[#173D30]">
          Order Online via WhatsApp
        </h1>
        <p className="text-sm sm:text-base text-[#242821]/80">
          Review your selected dishes, adjust quantities, enter your pickup or local delivery details, and send your itemized order request directly to {RESTAURANT_CONFIG.brandName} on WhatsApp.
        </p>
      </div>

      {/* Important Order & Pricing Disclaimer */}
      <div
        role="note"
        className="p-4 rounded-xl bg-white border border-[#173D30]/15 flex items-start gap-3 text-xs sm:text-sm text-[#242821]/85"
      >
        <AlertCircle
          className="w-5 h-5 text-[#C86F4A] shrink-0 mt-0.5"
          aria-hidden="true"
        />
        <div className="space-y-1">
          <p className="font-semibold text-[#173D30]">
            How WhatsApp Ordering Works (Please Read)
          </p>
          <p>{RESTAURANT_CONFIG.pricingDisclaimer.checkoutNotice}</p>
          <p className="text-xs text-[#242821]/70">
            {RESTAURANT_CONFIG.pricingDisclaimer.bannerText}
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
        {/* Left Column: Itemized Cart & Quick-Add Dishes */}
        <div className="lg:col-span-7 space-y-8">
          <div className="bg-white rounded-2xl border border-[#173D30]/15 p-6 sm:p-8 space-y-6 shadow-xs">
            <div className="flex items-center justify-between border-b border-[#173D30]/10 pb-4">
              <div className="flex items-center gap-2.5">
                <ShoppingBag className="w-5 h-5 text-[#C86F4A]" />
                <h2 className="font-serif-display text-xl sm:text-2xl font-bold text-[#173D30]">
                  Selected Dishes ({cart.reduce((s, i) => s + i.quantity, 0)})
                </h2>
              </div>

              {cart.length > 0 && (
                <button
                  type="button"
                  onClick={() => {
                    onClearCart();
                    setGeneratedWhatsAppUrl(null);
                  }}
                  className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#C86F4A] hover:underline"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Clear Cart</span>
                </button>
              )}
            </div>

            {cart.length === 0 ? (
              <div className="py-10 text-center space-y-4">
                <p className="font-serif-display text-lg font-semibold text-[#173D30]">
                  No dishes in your order tray yet
                </p>
                <p className="text-sm text-[#242821]/75 max-w-md mx-auto">
                  Browse our full menu or use the quick-add buttons below to add North Indian curries, Paneer 65, Veg Fried Rice, Cold Coffee and more.
                </p>
                <button
                  type="button"
                  onClick={() => onNavigate('menu')}
                  className="px-5 py-2.5 rounded-lg bg-[#173D30] text-[#FFF8ED] text-xs sm:text-sm font-semibold hover:bg-[#C86F4A] transition-colors inline-flex items-center gap-2"
                >
                  <Utensils className="w-4 h-4 text-[#D5AC65]" />
                  <span>Browse Full Menu</span>
                </button>
              </div>
            ) : (
              <div className="space-y-4">
                <ul className="divide-y divide-[#173D30]/10">
                  {cart.map((item) => {
                    const addOnSum = item.selectedAddOns.reduce(
                      (s, a) => s + a.price,
                      0
                    );
                    const unitPrice = item.menuItem.price + addOnSum;
                    const rowTotal = unitPrice * item.quantity;

                    return (
                      <li
                        key={item.cartItemId}
                        className="py-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4"
                      >
                        <div className="space-y-1">
                          <h3 className="font-semibold text-base text-[#242821]">
                            {item.menuItem.name}
                          </h3>
                          <p className="text-xs text-[#242821]/65 font-mono-num">
                            {item.menuItem.categoryLabel} · Base Price:{' '}
                            {RESTAURANT_CONFIG.currency.symbol}
                            {item.menuItem.price} (indicative)
                          </p>
                          {item.selectedAddOns.length > 0 && (
                            <p className="text-xs text-[#173D30] font-medium">
                              Add-ons:{' '}
                              {item.selectedAddOns
                                .map((a) => `${a.name} (+₹${a.price})`)
                                .join(', ')}
                            </p>
                          )}
                        </div>

                        <div className="flex items-center justify-between sm:justify-end gap-4 shrink-0">
                          <div className="inline-flex items-center border border-[#173D30]/20 rounded-lg bg-[#FFF8ED]">
                            <button
                              type="button"
                              onClick={() => {
                                onUpdateQuantity(item.cartItemId, -1);
                                setGeneratedWhatsAppUrl(null);
                              }}
                              aria-label={`Decrease ${item.menuItem.name}`}
                              className="w-8 h-8 flex items-center justify-center text-sm font-semibold text-[#173D30] hover:bg-[#173D30]/10 rounded-l-lg"
                            >
                              −
                            </button>
                            <span className="w-8 text-center font-mono-num text-xs font-semibold">
                              {item.quantity}
                            </span>
                            <button
                              type="button"
                              onClick={() => {
                                onUpdateQuantity(item.cartItemId, 1);
                                setGeneratedWhatsAppUrl(null);
                              }}
                              aria-label={`Increase ${item.menuItem.name}`}
                              className="w-8 h-8 flex items-center justify-center text-sm font-semibold text-[#173D30] hover:bg-[#173D30]/10 rounded-r-lg"
                            >
                              +
                            </button>
                          </div>

                          <div className="text-right min-w-[70px]">
                            <span className="font-mono-num text-sm font-bold text-[#173D30] block">
                              {RESTAURANT_CONFIG.currency.symbol}
                              {rowTotal}
                            </span>
                            <button
                              type="button"
                              onClick={() => {
                                onRemoveItem(item.cartItemId);
                                setGeneratedWhatsAppUrl(null);
                              }}
                              className="text-[11px] text-[#242821]/55 hover:text-[#C86F4A]"
                            >
                              Remove
                            </button>
                          </div>
                        </div>
                      </li>
                    );
                  })}
                </ul>

                {/* Subtotal Row */}
                <div className="pt-4 border-t border-[#173D30]/15 flex items-center justify-between">
                  <div>
                    <span className="text-sm font-semibold text-[#242821] block">
                      Indicative Order Subtotal
                    </span>
                    <span className="text-xs text-[#242821]/65">
                      Final bill & availability confirmed on WhatsApp
                    </span>
                  </div>
                  <span className="font-mono-num text-2xl font-bold text-[#173D30]">
                    {RESTAURANT_CONFIG.currency.symbol}
                    {subtotal}
                  </span>
                </div>
              </div>
            )}
          </div>

          {/* Quick-Add Popular Dishes */}
          <div className="bg-white/80 rounded-2xl border border-[#173D30]/12 p-6 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-serif-display text-lg font-bold text-[#173D30]">
                Quick-Add Popular Dishes
              </h3>
              <button
                type="button"
                onClick={() => onNavigate('menu')}
                className="text-xs font-semibold text-[#C86F4A] hover:underline"
              >
                Full Menu →
              </button>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {quickAddDishes.map((dish) => (
                <div
                  key={dish.id}
                  className="p-3 rounded-xl bg-[#FFF8ED] border border-[#173D30]/12 flex items-center justify-between gap-3"
                >
                  <div className="min-w-0">
                    <p className="text-xs font-semibold text-[#242821] truncate">
                      {dish.name}
                    </p>
                    <p className="text-[11px] text-[#173D30] font-mono-num">
                      {RESTAURANT_CONFIG.currency.symbol}
                      {dish.price} (indicative)
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      onAddToCart(dish, 1, []);
                      setGeneratedWhatsAppUrl(null);
                    }}
                    className="px-3 py-1.5 rounded-lg bg-[#173D30] hover:bg-[#C86F4A] text-[#FFF8ED] text-xs font-semibold inline-flex items-center gap-1 shrink-0 transition-colors"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Add</span>
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right Column: Checkout Form & WhatsApp Generator */}
        <div className="lg:col-span-5 bg-white rounded-2xl border border-[#173D30]/15 p-6 sm:p-8 shadow-xs space-y-6">
          <h2 className="font-serif-display text-2xl font-bold text-[#173D30]">
            Customer & Order Details
          </h2>

          <form onSubmit={handlePlaceOrder} noValidate className="space-y-4">
            {formError && (
              <div
                role="alert"
                className="p-3.5 rounded-lg bg-[#C86F4A]/10 border border-[#C86F4A] text-xs sm:text-sm text-[#242821] flex items-start gap-2.5"
              >
                <AlertCircle className="w-4 h-4 text-[#C86F4A] shrink-0 mt-0.5" />
                <span>{formError}</span>
              </div>
            )}

            {/* Customer Name */}
            <div>
              <label
                htmlFor="checkout-name"
                className="block text-xs font-semibold text-[#173D30] mb-1.5"
              >
                Customer Name *
              </label>
              <input
                id="checkout-name"
                type="text"
                required
                value={formData.customerName}
                onChange={(e) => {
                  setFormData({ ...formData, customerName: e.target.value });
                  setGeneratedWhatsAppUrl(null);
                }}
                placeholder="Enter your full name"
                className="w-full px-3.5 py-2.5 rounded-lg bg-[#FFF8ED] border border-[#173D30]/20 text-sm text-[#242821] focus:outline-none focus:border-[#173D30]"
              />
            </div>

            {/* Phone Number */}
            <div>
              <label
                htmlFor="checkout-phone"
                className="block text-xs font-semibold text-[#173D30] mb-1.5"
              >
                Phone Number (10-digit mobile) *
              </label>
              <input
                id="checkout-phone"
                type="tel"
                required
                value={formData.phoneNumber}
                onChange={(e) => {
                  setFormData({ ...formData, phoneNumber: e.target.value });
                  setGeneratedWhatsAppUrl(null);
                }}
                placeholder="e.g., 9876543210"
                className="w-full px-3.5 py-2.5 rounded-lg bg-[#FFF8ED] border border-[#173D30]/20 text-sm text-[#242821] font-mono-num focus:outline-none focus:border-[#173D30]"
              />
            </div>

            {/* Order Preference: Pickup vs Local Delivery Request */}
            <div>
              <span className="block text-xs font-semibold text-[#173D30] mb-1.5">
                Order Preference *
              </span>
              <div className="grid grid-cols-2 gap-2.5">
                <button
                  type="button"
                  onClick={() => {
                    setFormData({ ...formData, orderPreference: 'pickup' });
                    setGeneratedWhatsAppUrl(null);
                  }}
                  className={`py-2.5 px-3 rounded-lg text-xs sm:text-sm font-semibold border transition-colors ${
                    formData.orderPreference === 'pickup'
                      ? 'bg-[#173D30] text-[#FFF8ED] border-[#173D30]'
                      : 'bg-[#FFF8ED] text-[#242821] border-[#173D30]/20 hover:border-[#173D30]'
                  }`}
                >
                  Self Pickup / Takeaway
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setFormData({ ...formData, orderPreference: 'delivery' });
                    setGeneratedWhatsAppUrl(null);
                  }}
                  className={`py-2.5 px-3 rounded-lg text-xs sm:text-sm font-semibold border transition-colors ${
                    formData.orderPreference === 'delivery'
                      ? 'bg-[#173D30] text-[#FFF8ED] border-[#173D30]'
                      : 'bg-[#FFF8ED] text-[#242821] border-[#173D30]/20 hover:border-[#173D30]'
                  }`}
                >
                  Delivery Request
                </button>
              </div>
            </div>

            {/* Delivery Address (Required if Delivery selected) */}
            {formData.orderPreference === 'delivery' ? (
              <div>
                <label
                  htmlFor="checkout-address"
                  className="block text-xs font-semibold text-[#173D30] mb-1.5"
                >
                  Delivery Address & Landmark in Shivpuri *
                </label>
                <textarea
                  id="checkout-address"
                  rows={2}
                  required
                  value={formData.deliveryAddress}
                  onChange={(e) => {
                    setFormData({
                      ...formData,
                      deliveryAddress: e.target.value,
                    });
                    setGeneratedWhatsAppUrl(null);
                  }}
                  placeholder="House/Shop No., Street, Colony (e.g., Thakur Pura, Shivpuri) and nearby landmark"
                  className="w-full px-3.5 py-2.5 rounded-lg bg-[#FFF8ED] border border-[#173D30]/20 text-sm text-[#242821] focus:outline-none focus:border-[#173D30]"
                />
                <p className="text-[11px] text-[#242821]/65 mt-1">
                  Note: Delivery availability and any applicable charges depend on distance and are confirmed on WhatsApp.
                </p>
              </div>
            ) : (
              <div className="p-3 rounded-lg bg-[#173D30]/5 border border-[#173D30]/12 text-xs text-[#242821]/80">
                <strong className="text-[#173D30]">Pickup Address:</strong>{' '}
                {RESTAURANT_CONFIG.location.fullAddress}
              </div>
            )}

            {/* Order Notes */}
            <div>
              <label
                htmlFor="checkout-notes"
                className="block text-xs font-semibold text-[#173D30] mb-1.5"
              >
                Order Notes / Spice Preference (Optional)
              </label>
              <input
                id="checkout-notes"
                type="text"
                value={formData.orderNotes}
                onChange={(e) => {
                  setFormData({ ...formData, orderNotes: e.target.value });
                  setGeneratedWhatsAppUrl(null);
                }}
                placeholder="e.g., Less spicy, no onion/garlic, pickup at 7:30 PM"
                className="w-full px-3.5 py-2.5 rounded-lg bg-[#FFF8ED] border border-[#173D30]/20 text-sm text-[#242821] focus:outline-none focus:border-[#173D30]"
              />
            </div>

            {/* Submit / Validate Button */}
            <button
              type="submit"
              className="w-full py-3.5 px-5 rounded-lg bg-[#173D30] hover:bg-[#C86F4A] text-[#FFF8ED] font-semibold text-sm flex items-center justify-center gap-2 transition-colors shadow-sm"
            >
              <MessageCircle className="w-4 h-4 text-[#D5AC65]" />
              <span>Place Order Request via WhatsApp</span>
            </button>
          </form>

          {/* Generated WhatsApp Order Link Confirmation Box (Iframe-safe anchor link) */}
          {generatedWhatsAppUrl && (
            <div
              role="region"
              aria-label="WhatsApp Order Ready"
              className="p-5 rounded-xl bg-[#173D30] text-[#FFF8ED] border border-[#D5AC65]/40 space-y-3"
            >
              <div className="flex items-center gap-2 text-[#D5AC65]">
                <CheckCircle2 className="w-5 h-5 shrink-0" />
                <h3 className="font-serif-display text-base font-bold">
                  WhatsApp Order Message Ready!
                </h3>
              </div>
              <p className="text-xs text-[#FFF8ED]/85 leading-relaxed">
                Click the button below to open WhatsApp with your pre-filled order message to{' '}
                <strong className="font-mono-num">
                  {RESTAURANT_CONFIG.contact.phoneDisplay}
                </strong>
                .
              </p>

              <div className="p-3 rounded-lg bg-black/25 text-[11px] text-[#FFF8ED]/90 font-mono break-words">
                Hello {RESTAURANT_CONFIG.brandName}, I would like to place an order. Items: {buildItemsSummaryString()}. Subtotal: ₹{subtotal} (indicative). Name: {formData.customerName}. Order preference: {formData.orderPreference}. Address: {formData.orderPreference === 'delivery' ? formData.deliveryAddress : 'Pickup at Restaurant'}. Notes: {formData.orderNotes || 'None'}. Please confirm availability and the final bill.
              </div>

              <a
                href={generatedWhatsAppUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full py-3 px-4 rounded-lg bg-[#C86F4A] hover:bg-[#C86F4A]/90 text-[#FFF8ED] font-semibold text-sm flex items-center justify-center gap-2 transition-colors shadow-md"
              >
                <MessageCircle className="w-4 h-4" />
                <span>Open WhatsApp & Send Order Request</span>
              </a>

              <div className="pt-1 text-center">
                <a
                  href={`tel:${RESTAURANT_CONFIG.contact.phoneDial}`}
                  className="inline-flex items-center gap-1.5 text-xs text-[#D5AC65] hover:underline font-mono-num"
                >
                  <Phone className="w-3.5 h-3.5" />
                  <span>Or call {RESTAURANT_CONFIG.contact.phoneDisplay} directly</span>
                </a>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
