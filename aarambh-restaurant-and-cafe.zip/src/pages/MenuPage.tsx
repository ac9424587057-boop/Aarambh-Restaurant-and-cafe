import React, { useState, useMemo, useEffect } from 'react';
import { Search, X, AlertCircle, ShoppingBag, RotateCcw } from 'lucide-react';
import {
  MenuCategoryId,
  MenuItem,
  MenuAddOn,
  PageId,
} from '../types/restaurant';
import {
  RESTAURANT_CONFIG,
  MENU_CATEGORIES,
  MENU_ITEMS,
} from '../data/restaurantConfig';
import { DishCard } from '../components/DishCard';

interface MenuPageProps {
  initialCategory?: MenuCategoryId;
  onAddToCart: (item: MenuItem, quantity: number, addOns: MenuAddOn[]) => void;
  cartCount: number;
  cartSubtotal: number;
  onNavigate: (page: PageId) => void;
}

export const MenuPage: React.FC<MenuPageProps> = ({
  initialCategory = 'all',
  onAddToCart,
  cartCount,
  cartSubtotal,
  onNavigate,
}) => {
  const [selectedCategory, setSelectedCategory] =
    useState<MenuCategoryId>(initialCategory);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [sortOrder, setSortOrder] = useState<
    'recommended' | 'price-asc' | 'price-desc'
  >('recommended');
  const [isFiltering, setIsFiltering] = useState<boolean>(false);

  useEffect(() => {
    setSelectedCategory(initialCategory);
  }, [initialCategory]);

  const handleCategoryChange = (cat: MenuCategoryId) => {
    setIsFiltering(true);
    setSelectedCategory(cat);
    setTimeout(() => setIsFiltering(false), 120);
  };

  const filteredDishes = useMemo(() => {
    const query = searchQuery.trim().toLowerCase();

    const matches = MENU_ITEMS.filter((item) => {
      const matchesCategory =
        selectedCategory === 'all' || item.category === selectedCategory;
      const matchesQuery =
        !query ||
        item.name.toLowerCase().includes(query) ||
        item.description.toLowerCase().includes(query) ||
        item.categoryLabel.toLowerCase().includes(query);

      return matchesCategory && matchesQuery;
    });

    if (sortOrder === 'price-asc') {
      return [...matches].sort((a, b) => a.price - b.price);
    }
    if (sortOrder === 'price-desc') {
      return [...matches].sort((a, b) => b.price - a.price);
    }
    return matches;
  }, [selectedCategory, searchQuery, sortOrder]);

  const resetFilters = () => {
    setSelectedCategory('all');
    setSearchQuery('');
    setSortOrder('recommended');
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-14 space-y-8">
      {/* Page Header */}
      <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-6 border-b border-[#173D30]/15 pb-8">
        <div className="space-y-2 max-w-3xl">
          <p className="text-xs font-semibold text-[#C86F4A]">
            {RESTAURANT_CONFIG.brandName} · Thakur Pura, Shivpuri
          </p>
          <h1 className="font-serif-display text-3xl sm:text-4xl font-bold text-[#173D30]">
            Our Vegetarian Restaurant & Cafe Menu
          </h1>
          <p className="text-sm sm:text-base text-[#242821]/80">
            Browse North Indian curries and thalis, Indo-Chinese starters, oven-baked fast food, chilled cafe beverages and traditional desserts. Select quantities and optional add-ons to build your WhatsApp order request.
          </p>
        </div>

        {/* Cart Summary Box on Menu Page */}
        {cartCount > 0 && (
          <div className="bg-[#173D30] text-[#FFF8ED] p-4 rounded-xl flex items-center justify-between gap-4 shrink-0 shadow-sm">
            <div>
              <p className="text-xs text-[#D5AC65] font-medium">
                Order Tray Ready
              </p>
              <p className="text-sm font-semibold font-mono-num">
                {cartCount} {cartCount === 1 ? 'dish' : 'dishes'} ·{' '}
                {RESTAURANT_CONFIG.currency.symbol}
                {cartSubtotal}
              </p>
            </div>
            <button
              type="button"
              onClick={() => {
                onNavigate('order');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className="px-4 py-2 rounded-lg bg-[#C86F4A] hover:bg-[#C86F4A]/90 text-[#FFF8ED] text-xs font-semibold inline-flex items-center gap-1.5 whitespace-nowrap"
            >
              <ShoppingBag className="w-3.5 h-3.5" />
              <span>Checkout</span>
            </button>
          </div>
        )}
      </div>

      {/* Preliminary / Indicative Price Notice Banner */}
      <div
        role="note"
        aria-label="Indicative Menu Pricing Notice"
        className="p-4 rounded-xl bg-white border border-[#C86F4A]/35 flex items-start gap-3 text-xs sm:text-sm text-[#242821]/85"
      >
        <AlertCircle
          className="w-5 h-5 text-[#C86F4A] shrink-0 mt-0.5"
          aria-hidden="true"
        />
        <div className="space-y-1">
          <p className="font-semibold text-[#173D30]">
            Preliminary Reference & Sample Menu Prices
          </p>
          <p className="leading-relaxed">
            {RESTAURANT_CONFIG.pricingDisclaimer.bannerText}
          </p>
        </div>
      </div>

      {/* Search, Sort & Category Filter Bar */}
      <div className="space-y-4">
        <div className="flex flex-col md:flex-row gap-3">
          {/* Search Input */}
          <div className="relative flex-1">
            <Search
              className="w-4 h-4 text-[#242821]/50 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none"
              aria-hidden="true"
            />
            <input
              type="search"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search dishes (e.g., Paneer 65, Veg Fried Rice, Kaju Curry, Cold Coffee, Maggi)..."
              aria-label="Search menu dishes"
              className="w-full pl-10 pr-10 py-2.5 bg-white border border-[#173D30]/20 rounded-lg text-sm text-[#242821] placeholder:text-[#242821]/45 focus:outline-none focus:border-[#173D30] focus:ring-1 focus:ring-[#173D30]"
            />
            {searchQuery && (
              <button
                type="button"
                onClick={() => setSearchQuery('')}
                aria-label="Clear search query"
                className="absolute right-3 top-1/2 -translate-y-1/2 text-[#242821]/50 hover:text-[#242821] p-1"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          {/* Sort Selector */}
          <div className="flex items-center gap-2 shrink-0">
            <label
              htmlFor="menu-sort"
              className="text-xs font-medium text-[#242821]/70 whitespace-nowrap"
            >
              Sort by:
            </label>
            <select
              id="menu-sort"
              value={sortOrder}
              onChange={(e) =>
                setSortOrder(
                  e.target.value as 'recommended' | 'price-asc' | 'price-desc'
                )
              }
              className="py-2.5 px-3 bg-white border border-[#173D30]/20 rounded-lg text-xs sm:text-sm font-medium text-[#242821] focus:outline-none focus:border-[#173D30]"
            >
              <option value="recommended">Recommended Order</option>
              <option value="price-asc">Price: Low to High</option>
              <option value="price-desc">Price: High to Low</option>
            </select>
          </div>
        </div>

        {/* Category Filter Tabs (Interactive Functional Buttons) */}
        <div
          role="tablist"
          aria-label="Menu Categories"
          className="flex items-center gap-1.5 p-1.5 bg-[#173D30]/8 rounded-xl overflow-x-auto"
        >
          {MENU_CATEGORIES.map((category) => {
            const isActive = selectedCategory === category.id;
            return (
              <button
                key={category.id}
                role="tab"
                type="button"
                aria-selected={isActive}
                onClick={() => handleCategoryChange(category.id)}
                className={`px-4 py-2 rounded-lg text-xs sm:text-sm font-semibold transition-colors whitespace-nowrap shrink-0 min-h-[40px] focus-visible:outline-2 focus-visible:outline-[#173D30] ${
                  isActive
                    ? 'bg-[#173D30] text-[#FFF8ED] shadow-xs'
                    : 'text-[#242821]/80 hover:text-[#173D30] hover:bg-white/60'
                }`}
              >
                <span>{category.label}</span>
                <span
                  className={`ml-1.5 font-mono-num text-xs ${
                    isActive ? 'text-[#D5AC65]' : 'text-[#242821]/50'
                  }`}
                >
                  ({category.dishCount})
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Results Count & Active Filter Status */}
      <div className="flex items-center justify-between text-xs text-[#242821]/70">
        <p>
          Showing <strong className="font-mono-num text-[#173D30]">{filteredDishes.length}</strong>{' '}
          {filteredDishes.length === 1 ? 'dish' : 'dishes'}
          {selectedCategory !== 'all' &&
            ` in ${
              MENU_CATEGORIES.find((c) => c.id === selectedCategory)?.label
            }`}
          {searchQuery && ` matching "${searchQuery}"`}
        </p>

        {(selectedCategory !== 'all' || searchQuery !== '' || sortOrder !== 'recommended') && (
          <button
            type="button"
            onClick={resetFilters}
            className="inline-flex items-center gap-1 text-[#C86F4A] font-semibold hover:underline"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset Filters</span>
          </button>
        )}
      </div>

      {/* Loading Skeleton or Dishes Grid */}
      {isFiltering ? (
        <div
          aria-live="polite"
          aria-busy="true"
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8"
        >
          {[1, 2, 3, 4, 5, 6].map((n) => (
            <div
              key={n}
              className="h-96 rounded-xl bg-white/60 border border-[#173D30]/10 p-5 animate-pulse flex flex-col justify-between"
            >
              <div className="aspect-4/3 w-full bg-[#173D30]/10 rounded-lg" />
              <div className="space-y-2">
                <div className="h-4 w-1/3 bg-[#173D30]/10 rounded" />
                <div className="h-5 w-2/3 bg-[#173D30]/15 rounded" />
                <div className="h-3 w-full bg-[#173D30]/10 rounded" />
              </div>
              <div className="h-10 w-full bg-[#173D30]/10 rounded-lg" />
            </div>
          ))}
        </div>
      ) : filteredDishes.length === 0 ? (
        /* Helpful Empty State */
        <div className="bg-white rounded-2xl border border-[#173D30]/15 p-10 text-center max-w-lg mx-auto my-8 space-y-4">
          <p className="font-serif-display text-xl font-semibold text-[#173D30]">
            No matching dishes found
          </p>
          <p className="text-sm text-[#242821]/75">
            We couldn’t find any items matching "{searchQuery}" in the selected category. Try clearing your search filter or ask us directly on WhatsApp for special requests.
          </p>
          <div className="pt-2 flex flex-wrap items-center justify-center gap-3">
            <button
              type="button"
              onClick={resetFilters}
              className="px-5 py-2.5 rounded-lg bg-[#173D30] text-[#FFF8ED] text-xs sm:text-sm font-semibold hover:bg-[#C86F4A] transition-colors"
            >
              Show All {MENU_ITEMS.length} Dishes
            </button>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
          {filteredDishes.map((dish) => (
            <DishCard key={dish.id} item={dish} onAddToCart={onAddToCart} />
          ))}
        </div>
      )}
    </div>
  );
};
