import React, { useState } from 'react';
import {
  MapPin,
  Phone,
  Clock,
  MessageCircle,
  ExternalLink,
  CheckCircle2,
  AlertCircle,
  Send,
} from 'lucide-react';
import {
  RESTAURANT_CONFIG,
  buildWhatsAppEnquiryUrl,
} from '../data/restaurantConfig';

export const ContactPage: React.FC = () => {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [topic, setTopic] = useState('Table / Group Dining Enquiry');
  const [message, setMessage] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [submitted, setSubmitted] = useState(false);

  const validatePhone = (value: string) => {
    const cleaned = value.replace(/[\s\-+]/g, '');
    return /^[0-9]{10,13}$/.test(cleaned);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (name.trim().length < 2) {
      setError('Please enter your full name (at least 2 characters).');
      return;
    }
    if (!validatePhone(phone)) {
      setError('Please enter a valid 10-digit Indian mobile/phone number.');
      return;
    }
    if (message.trim().length < 5) {
      setError('Please enter a brief message or enquiry (at least 5 characters).');
      return;
    }

    setSubmitted(true);
  };

  const whatsappDirectEnquiryLink = buildWhatsAppEnquiryUrl(
    `Hello ${RESTAURANT_CONFIG.brandName}, Name: ${name.trim() || 'Guest'}. Phone: ${phone.trim() || 'N/A'}. Topic: ${topic}. Enquiry: ${message.trim()}`
  );

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-14 space-y-12">
      {/* Header */}
      <div className="border-b border-[#173D30]/15 pb-8 space-y-2 max-w-3xl">
        <p className="text-xs font-semibold text-[#C86F4A]">
          Thakur Pura, Shivpuri (Madhya Pradesh – 473638)
        </p>
        <h1 className="font-serif-display text-3xl sm:text-4xl font-bold text-[#173D30]">
          Contact & Location
        </h1>
        <p className="text-sm sm:text-base text-[#242821]/80">
          Reach {RESTAURANT_CONFIG.brandName} by phone, WhatsApp, or visit us in front of Katha Mill, near Panchmukhi Hanuman Temple in Thakur Pura, Shivpuri.
        </p>
      </div>

      {/* Main Two-Column Grid: Direct Contact & Map Card Left, Validated Contact Form Right */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
        {/* Left Column: Address, Hours, Direct Action Buttons & Directions Card */}
        <div className="lg:col-span-6 space-y-6">
          <div className="bg-white rounded-2xl border border-[#173D30]/15 p-6 sm:p-8 space-y-6 shadow-xs">
            <h2 className="font-serif-display text-2xl font-bold text-[#173D30]">
              Direct Contact & Directions
            </h2>

            <div className="space-y-5 text-sm">
              <div className="flex items-start gap-3.5">
                <div className="w-10 h-10 rounded-lg bg-[#173D30]/10 text-[#173D30] flex items-center justify-center shrink-0">
                  <MapPin className="w-5 h-5 text-[#C86F4A]" aria-hidden="true" />
                </div>
                <div>
                  <h3 className="font-semibold text-[#173D30]">
                    Restaurant Address & Landmark
                  </h3>
                  <p className="text-[#242821]/85 mt-1 leading-relaxed">
                    {RESTAURANT_CONFIG.location.fullAddress}
                  </p>
                  <p className="text-xs text-[#C86F4A] mt-1 font-medium">
                    Landmark: {RESTAURANT_CONFIG.location.landmarkReference}
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3.5">
                <div className="w-10 h-10 rounded-lg bg-[#173D30]/10 text-[#173D30] flex items-center justify-center shrink-0">
                  <Phone className="w-5 h-5 text-[#C86F4A]" aria-hidden="true" />
                </div>
                <div>
                  <h3 className="font-semibold text-[#173D30]">
                    Phone & WhatsApp Number
                  </h3>
                  <p className="font-mono-num text-base font-bold text-[#173D30] mt-0.5">
                    {RESTAURANT_CONFIG.contact.phoneDisplay}
                  </p>
                  <p className="text-xs text-[#242821]/65 mt-0.5">
                    Click below to dial directly or start a WhatsApp chat.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3.5">
                <div className="w-10 h-10 rounded-lg bg-[#173D30]/10 text-[#173D30] flex items-center justify-center shrink-0">
                  <Clock className="w-5 h-5 text-[#C86F4A]" aria-hidden="true" />
                </div>
                <div>
                  <h3 className="font-semibold text-[#173D30]">
                    Configurable Opening Hours
                  </h3>
                  <p className="font-mono-num font-semibold text-[#242821] mt-0.5">
                    {RESTAURANT_CONFIG.openingHours.listedHours}
                  </p>
                  <p className="text-xs text-[#242821]/70 mt-0.5">
                    {RESTAURANT_CONFIG.openingHours.statusNote}
                  </p>
                </div>
              </div>
            </div>

            {/* 3 Primary Action Buttons: Click-to-Call, WhatsApp, Google Maps */}
            <div className="pt-4 border-t border-[#173D30]/10 grid grid-cols-1 sm:grid-cols-3 gap-3">
              <a
                href={`tel:${RESTAURANT_CONFIG.contact.phoneDial}`}
                className="py-3 px-4 rounded-lg bg-[#173D30] hover:bg-[#173D30]/90 text-[#FFF8ED] text-xs sm:text-sm font-semibold flex items-center justify-center gap-2 transition-colors whitespace-nowrap"
              >
                <Phone className="w-4 h-4 text-[#D5AC65]" />
                <span>Call Restaurant</span>
              </a>

              <a
                href={buildWhatsAppEnquiryUrl()}
                target="_blank"
                rel="noopener noreferrer"
                className="py-3 px-4 rounded-lg bg-[#C86F4A] hover:bg-[#C86F4A]/90 text-[#FFF8ED] text-xs sm:text-sm font-semibold flex items-center justify-center gap-2 transition-colors whitespace-nowrap"
              >
                <MessageCircle className="w-4 h-4" />
                <span>WhatsApp Us</span>
              </a>

              <a
                href={RESTAURANT_CONFIG.location.googleMapsUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="py-3 px-4 rounded-lg border border-[#173D30]/25 hover:bg-[#173D30]/5 text-[#173D30] text-xs sm:text-sm font-semibold flex items-center justify-center gap-2 transition-colors whitespace-nowrap"
              >
                <span>Google Maps</span>
                <ExternalLink className="w-4 h-4 text-[#C86F4A]" />
              </a>
            </div>
          </div>

          {/* Verified Google Maps Card (No guessed coordinates) */}
          <div className="bg-[#173D30] text-[#FFF8ED] rounded-2xl p-6 sm:p-8 border border-[#D5AC65]/30 space-y-4">
            <div className="flex items-center justify-between gap-4">
              <div>
                <p className="text-xs font-semibold text-[#D5AC65]">
                  Verified Google Maps Link
                </p>
                <h3 className="font-serif-display text-xl font-bold mt-0.5">
                  Find Us in Thakur Pura, Shivpuri
                </h3>
              </div>
              <MapPin className="w-8 h-8 text-[#D5AC65] shrink-0" />
            </div>
            <p className="text-xs sm:text-sm text-[#FFF8ED]/85 leading-relaxed">
              We are located in front of Katha Mill, near Panchmukhi Hanuman Temple, Thakur Pura, Shivpuri, Madhya Pradesh – 473638. Use our official Google Maps listing for live turn-by-turn navigation.
            </p>
            <div>
              <a
                href={RESTAURANT_CONFIG.location.googleMapsUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg bg-[#D5AC65] text-[#242821] font-semibold text-xs sm:text-sm hover:bg-[#D5AC65]/90 transition-colors"
              >
                <span>Open Location in Google Maps</span>
                <ExternalLink className="w-4 h-4" />
              </a>
            </div>
          </div>
        </div>

        {/* Right Column: Contact & Enquiry Form */}
        <div className="lg:col-span-6 bg-white rounded-2xl border border-[#173D30]/15 p-6 sm:p-8 shadow-xs">
          <h2 className="font-serif-display text-2xl font-bold text-[#173D30]">
            Send an Enquiry
          </h2>
          <p className="text-xs sm:text-sm text-[#242821]/75 mt-1 mb-6">
            Fill in your details below to prepare an enquiry for table seating, family gatherings, student group orders or menu questions.
          </p>

          {submitted ? (
            <div
              role="status"
              aria-live="polite"
              className="p-6 rounded-xl bg-[#173D30]/5 border border-[#173D30]/20 space-y-4"
            >
              <div className="flex items-center gap-2.5 text-[#173D30]">
                <CheckCircle2 className="w-6 h-6 text-[#173D30] shrink-0" />
                <h3 className="font-serif-display text-lg font-bold">
                  Enquiry Prepared Successfully
                </h3>
              </div>
              <p className="text-sm text-[#242821]/85 leading-relaxed">
                Thank you, <strong>{name}</strong>. Your message regarding{' '}
                <strong>{topic}</strong> is ready. For the fastest response from our team at Thakur Pura, Shivpuri, click below to send this directly via WhatsApp or call us.
              </p>

              <div className="flex flex-wrap items-center gap-3 pt-2">
                <a
                  href={whatsappDirectEnquiryLink}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-5 py-2.5 rounded-lg bg-[#C86F4A] hover:bg-[#C86F4A]/90 text-[#FFF8ED] text-xs sm:text-sm font-semibold inline-flex items-center gap-2"
                >
                  <MessageCircle className="w-4 h-4" />
                  <span>Send Enquiry on WhatsApp</span>
                </a>
                <button
                  type="button"
                  onClick={() => {
                    setSubmitted(false);
                    setMessage('');
                  }}
                  className="px-4 py-2.5 rounded-lg border border-[#173D30]/20 text-xs sm:text-sm font-medium text-[#173D30] hover:bg-[#173D30]/5"
                >
                  Write Another Message
                </button>
              </div>
            </div>
          ) : (
            <form onSubmit={handleSubmit} noValidate className="space-y-4">
              {error && (
                <div
                  role="alert"
                  className="p-3.5 rounded-lg bg-[#C86F4A]/10 border border-[#C86F4A] text-xs sm:text-sm text-[#242821] flex items-start gap-2.5"
                >
                  <AlertCircle className="w-4 h-4 text-[#C86F4A] shrink-0 mt-0.5" />
                  <span>{error}</span>
                </div>
              )}

              <div>
                <label
                  htmlFor="contact-name"
                  className="block text-xs font-semibold text-[#173D30] mb-1.5"
                >
                  Your Full Name *
                </label>
                <input
                  id="contact-name"
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g., Rahul Sharma"
                  className="w-full px-3.5 py-2.5 rounded-lg bg-[#FFF8ED] border border-[#173D30]/20 text-sm text-[#242821] focus:outline-none focus:border-[#173D30]"
                />
              </div>

              <div>
                <label
                  htmlFor="contact-phone"
                  className="block text-xs font-semibold text-[#173D30] mb-1.5"
                >
                  Phone / WhatsApp Number *
                </label>
                <input
                  id="contact-phone"
                  type="tel"
                  required
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="e.g., 9876543210"
                  className="w-full px-3.5 py-2.5 rounded-lg bg-[#FFF8ED] border border-[#173D30]/20 text-sm text-[#242821] font-mono-num focus:outline-none focus:border-[#173D30]"
                />
              </div>

              <div>
                <label
                  htmlFor="contact-topic"
                  className="block text-xs font-semibold text-[#173D30] mb-1.5"
                >
                  Enquiry Topic
                </label>
                <select
                  id="contact-topic"
                  value={topic}
                  onChange={(e) => setTopic(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-lg bg-[#FFF8ED] border border-[#173D30]/20 text-sm text-[#242821] focus:outline-none focus:border-[#173D30]"
                >
                  <option value="Table / Group Dining Enquiry">
                    Table / Family Dining Enquiry
                  </option>
                  <option value="Takeaway / Bulk Order Question">
                    Takeaway / Bulk Order Question
                  </option>
                  <option value="Menu & Dish Availability">
                    Menu & Dish Availability
                  </option>
                  <option value="General Feedback">General Question / Feedback</option>
                </select>
              </div>

              <div>
                <label
                  htmlFor="contact-message"
                  className="block text-xs font-semibold text-[#173D30] mb-1.5"
                >
                  Your Message *
                </label>
                <textarea
                  id="contact-message"
                  rows={4}
                  required
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="Tell us how many guests are visiting, preferred time, or any dish questions..."
                  className="w-full px-3.5 py-2.5 rounded-lg bg-[#FFF8ED] border border-[#173D30]/20 text-sm text-[#242821] focus:outline-none focus:border-[#173D30]"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3 px-5 rounded-lg bg-[#173D30] hover:bg-[#C86F4A] text-[#FFF8ED] font-semibold text-sm flex items-center justify-center gap-2 transition-colors"
              >
                <Send className="w-4 h-4 text-[#D5AC65]" />
                <span>Validate & Prepare Enquiry</span>
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
