import React from 'react';
import { MapPin, Clock, Phone, Utensils, Users, MessageCircle } from 'lucide-react';
import { PageId } from '../types/restaurant';
import {
  RESTAURANT_CONFIG,
  IMAGES,
  buildWhatsAppEnquiryUrl,
} from '../data/restaurantConfig';
import { FoodImage } from '../components/FoodImage';

interface AboutPageProps {
  onNavigate: (page: PageId) => void;
}

export const AboutPage: React.FC<AboutPageProps> = ({ onNavigate }) => {
  const navigateTop = (page: PageId) => {
    onNavigate(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-16 space-y-16">
      {/* Hero Intro */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
        <div className="lg:col-span-6 space-y-5">
          <p className="text-xs font-semibold text-[#C86F4A]">
            About Our Restaurant & Cafe
          </p>
          <h1
            className="font-serif-display text-3xl sm:text-4xl font-bold text-[#173D30] leading-tight"
            style={{ textWrap: 'balance' }}
          >
            {RESTAURANT_CONFIG.brandName} — Thakur Pura, Shivpuri
          </h1>
          <p className="text-base text-[#242821]/85 leading-relaxed">
            {RESTAURANT_CONFIG.supportingIntro}
          </p>
          <p className="text-sm sm:text-base text-[#242821]/80 leading-relaxed">
            Located in front of Katha Mill, near Panchmukhi Hanuman Temple in Thakur Pura, Shivpuri (Madhya Pradesh – 473638), our space is designed to bridge the gap between a traditional Indian family dining room and a friendly local cafe.
          </p>

          <div className="pt-2 flex flex-wrap items-center gap-4">
            <button
              type="button"
              onClick={() => navigateTop('menu')}
              className="px-5 py-3 rounded-lg bg-[#173D30] hover:bg-[#C86F4A] text-[#FFF8ED] text-sm font-semibold inline-flex items-center gap-2 transition-colors"
            >
              <Utensils className="w-4 h-4 text-[#D5AC65]" />
              <span>Explore Our Menu</span>
            </button>
            <a
              href={buildWhatsAppEnquiryUrl()}
              target="_blank"
              rel="noopener noreferrer"
              className="px-5 py-3 rounded-lg border border-[#173D30]/25 hover:bg-[#173D30]/5 text-[#173D30] text-sm font-semibold inline-flex items-center gap-2 transition-colors"
            >
              <MessageCircle className="w-4 h-4 text-[#C86F4A]" />
              <span>Enquire on WhatsApp</span>
            </a>
          </div>
        </div>

        <div className="lg:col-span-6">
          <div className="rounded-2xl overflow-hidden border border-[#173D30]/15 shadow-lg aspect-16/9">
            <FoodImage
              src={IMAGES.HERO_SPREAD}
              alt="Illustrative spread of Indian dishes and cafe drinks representing Aarambh Restaurant and Cafe"
              containerClassName="w-full h-full relative"
            />
          </div>
        </div>
      </div>

      {/* Who We Serve & What We Prepare */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="bg-white rounded-2xl p-6 sm:p-8 border border-[#173D30]/12 space-y-4">
          <div className="flex items-center gap-2 text-[#C86F4A] text-xs font-semibold">
            <Users className="w-4 h-4" />
            <span>Guests We Welcome</span>
          </div>
          <h2 className="font-serif-display text-2xl font-bold text-[#173D30]">
            A Place for Families, Students & Takeaway Guests
          </h2>
          <p className="text-sm text-[#242821]/80 leading-relaxed">
            In Shivpuri, dining out often means different cravings at the same table—some guests want hot tandoori rotis with Paneer Butter Masala or Dal, while younger guests or students prefer Chilli Paneer, Veg Fried Rice, Pizza, Maggi or Cold Coffee.
          </p>
          <ul className="space-y-2.5 pt-2 text-sm text-[#242821]/85">
            {RESTAURANT_CONFIG.targetCustomers.map((guest, i) => (
              <li key={i} className="flex items-start gap-2.5">
                <span className="font-mono-num text-xs font-semibold text-[#C86F4A] mt-0.5">
                  0{i + 1}.
                </span>
                <span>{guest}</span>
              </li>
            ))}
          </ul>
        </div>

        <div className="bg-white rounded-2xl p-6 sm:p-8 border border-[#173D30]/12 space-y-4">
          <div className="flex items-center gap-2 text-[#C86F4A] text-xs font-semibold">
            <Utensils className="w-4 h-4" />
            <span>Our Kitchen & Cafe Philosophy</span>
          </div>
          <h2 className="font-serif-display text-2xl font-bold text-[#173D30]">
            Transparent Information & Fresh Preparation
          </h2>
          <p className="text-sm text-[#242821]/80 leading-relaxed">
            We believe in straightforward, honest hospitality. On this website, you can browse our full menu structure across five categories, prepare an itemized order tray, and connect directly with our staff on WhatsApp or by telephone.
          </p>
          <div className="p-4 rounded-xl bg-[#FFF8ED] border border-[#173D30]/10 space-y-2 text-xs text-[#242821]/80">
            <p className="font-semibold text-[#173D30]">
              Transparency Note for Online Visitors:
            </p>
            <p>{RESTAURANT_CONFIG.pricingDisclaimer.bannerText}</p>
            <p>{RESTAURANT_CONFIG.imageDisclaimer}</p>
          </div>
        </div>
      </div>

      {/* Verified Business Details Card */}
      <div className="bg-[#173D30] text-[#FFF8ED] rounded-2xl p-6 sm:p-10 border border-[#D5AC65]/25">
        <h2 className="font-serif-display text-2xl font-bold text-[#FFF8ED] mb-6">
          At-a-Glance Business Information
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-sm">
          <div className="space-y-1.5">
            <p className="text-xs text-[#D5AC65] font-medium flex items-center gap-1.5">
              <MapPin className="w-4 h-4" />
              <span>Location & Address Reference</span>
            </p>
            <p className="text-[#FFF8ED] font-medium">
              {RESTAURANT_CONFIG.location.fullAddress}
            </p>
          </div>

          <div className="space-y-1.5">
            <p className="text-xs text-[#D5AC65] font-medium flex items-center gap-1.5">
              <Clock className="w-4 h-4" />
              <span>Listed Opening Hours</span>
            </p>
            <p className="text-[#FFF8ED] font-mono-num font-medium">
              {RESTAURANT_CONFIG.openingHours.listedHours}
            </p>
            <p className="text-xs text-[#FFF8ED]/75">
              {RESTAURANT_CONFIG.openingHours.statusNote}
            </p>
          </div>

          <div className="space-y-1.5">
            <p className="text-xs text-[#D5AC65] font-medium flex items-center gap-1.5">
              <Phone className="w-4 h-4" />
              <span>Direct Phone & WhatsApp</span>
            </p>
            <p className="font-mono-num text-[#FFF8ED] font-semibold">
              {RESTAURANT_CONFIG.contact.phoneDisplay}
            </p>
            <p className="text-xs text-[#FFF8ED]/75">
              Currency: {RESTAURANT_CONFIG.currency.code} ({RESTAURANT_CONFIG.currency.symbol})
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
