import React from 'react';
import {
  ArrowRight,
  MessageCircle,
  MapPin,
  Clock,
  Phone,
  ExternalLink,
  Utensils,
} from 'lucide-react';
import {
  MenuItem,
  MenuAddOn,
  MenuCategoryId,
  PageId,
} from '../types/restaurant';
import {
  RESTAURANT_CONFIG,
  MENU_ITEMS,
  MENU_CATEGORIES,
  GALLERY_PHOTOS,
  IMAGES,
  buildWhatsAppEnquiryUrl,
} from '../data/restaurantConfig';
import { FoodImage } from '../components/FoodImage';
import { DishCard } from '../components/DishCard';

interface HomePageProps {
  onNavigate: (page: PageId) => void;
  onSelectCategoryAndNavigate: (category: MenuCategoryId) => void;
  onAddToCart: (item: MenuItem, quantity: number, addOns: MenuAddOn[]) => void;
}

export const HomePage: React.FC<HomePageProps> = ({
  onNavigate,
  onSelectCategoryAndNavigate,
  onAddToCart,
}) => {
  const featuredDishes = MENU_ITEMS.filter((item) => item.isFeatured).slice(0, 6);
  const displayCategories = MENU_CATEGORIES.filter((cat) => cat.id !== 'all');

  const navigateTop = (page: PageId) => {
    onNavigate(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="space-y-16 sm:space-y-24 pb-12">
      {/* 1. HERO SECTION */}
      <section className="relative bg-[#173D30] text-[#FFF8ED] overflow-hidden border-b border-[#D5AC65]/25">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-16 lg:py-20">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-stretch">
            {/* Left Copy Column */}
            <div className="lg:col-span-6 flex flex-col justify-center space-y-6">
              <div className="flex flex-wrap items-center gap-2 text-xs sm:text-sm text-[#D5AC65] font-medium">
                <span>{RESTAURANT_CONFIG.location.area}, {RESTAURANT_CONFIG.location.city}</span>
                <span aria-hidden="true">·</span>
                <span>100% Vegetarian Kitchen & Cafe</span>
              </div>

              <h1
                className="font-serif-display font-bold text-[#FFF8ED] tracking-tight leading-[1.12]"
                style={{
                  fontSize: 'clamp(2.25rem, 4vw, 3.75rem)',
                  textWrap: 'balance',
                }}
              >
                {RESTAURANT_CONFIG.tagline}
              </h1>

              <p className="text-base sm:text-lg text-[#FFF8ED]/85 leading-relaxed max-w-2xl">
                {RESTAURANT_CONFIG.supportingIntro}
              </p>

              {/* Primary CTA & Secondary CTA */}
              <div className="pt-2 flex flex-wrap items-center gap-4">
                <button
                  type="button"
                  onClick={() => navigateTop('menu')}
                  className="px-6 py-3.5 rounded-lg bg-[#C86F4A] hover:bg-[#C86F4A]/90 text-[#FFF8ED] font-semibold text-sm sm:text-base inline-flex items-center gap-2 transition-colors whitespace-nowrap shrink-0 shadow-sm focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#D5AC65]"
                >
                  <Utensils className="w-4 h-4" aria-hidden="true" />
                  <span>Explore Menu</span>
                </button>

                <a
                  href={buildWhatsAppEnquiryUrl(
                    `Hello ${RESTAURANT_CONFIG.brandName}, I would like to see the menu and place an order.`
                  )}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-6 py-3.5 rounded-lg border border-[#D5AC65]/60 hover:bg-[#FFF8ED]/10 text-[#FFF8ED] font-semibold text-sm sm:text-base inline-flex items-center gap-2 transition-colors whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#D5AC65]"
                >
                  <MessageCircle className="w-4 h-4 text-[#D5AC65]" aria-hidden="true" />
                  <span>Order on WhatsApp</span>
                </a>
              </div>

              {/* Location & Listed Hours Summary Strip */}
              <div className="pt-4 border-t border-[#FFF8ED]/15 grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs text-[#FFF8ED]/80">
                <div className="flex items-start gap-2">
                  <MapPin className="w-4 h-4 text-[#D5AC65] shrink-0 mt-0.5" aria-hidden="true" />
                  <span>
                    {RESTAURANT_CONFIG.location.landmarkReference}, {RESTAURANT_CONFIG.location.area}, {RESTAURANT_CONFIG.location.city} – {RESTAURANT_CONFIG.location.postalCode}
                  </span>
                </div>
                <div className="flex items-start gap-2">
                  <Clock className="w-4 h-4 text-[#D5AC65] shrink-0 mt-0.5" aria-hidden="true" />
                  <span>{RESTAURANT_CONFIG.openingHours.statusNote}</span>
                </div>
              </div>
            </div>

            {/* Right Image Column */}
            <div className="lg:col-span-6 flex">
              <div className="w-full rounded-2xl overflow-hidden border border-[#D5AC65]/30 shadow-xl relative min-h-[300px] sm:min-h-[380px] lg:h-full">
                <FoodImage
                  src={IMAGES.HERO_SPREAD}
                  alt="Illustrative spread of Paneer Butter Masala, garlic naan, Chilli Paneer and Cold Coffee at Aarambh Restaurant and Cafe"
                  priority={true}
                  containerClassName="w-full h-full relative overflow-hidden"
                  className="w-full h-full object-cover"
                  captionOverlay="North Indian Curries · Indo-Chinese Starters · Cafe & Beverages (Illustrative Photography)"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 2. FEATURED DISHES */}
      <section
        aria-labelledby="featured-dishes-heading"
        className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8"
      >
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-8">
          <div>
            <p className="text-xs font-semibold text-[#C86F4A] tracking-wide">
              Kitchen & Cafe Highlights
            </p>
            <h2
              id="featured-dishes-heading"
              className="font-serif-display text-2xl sm:text-3xl font-bold text-[#173D30] mt-1"
            >
              Featured Dishes at Aarambh
            </h2>
            <p className="text-sm text-[#242821]/75 mt-1 max-w-2xl">
              Popular choices across our North Indian, Indo-Chinese and Cafe menu. Add items directly to your order tray to generate a WhatsApp order request.
            </p>
          </div>
          <button
            type="button"
            onClick={() => navigateTop('menu')}
            className="inline-flex items-center gap-1.5 text-sm font-semibold text-[#173D30] hover:text-[#C86F4A] transition-colors whitespace-nowrap shrink-0 self-start md:self-auto"
          >
            <span>View All {MENU_ITEMS.length} Dishes</span>
            <ArrowRight className="w-4 h-4" aria-hidden="true" />
          </button>
        </div>

        {/* Indicative Price Transparency Notice */}
        <div className="mb-6 p-3.5 rounded-lg bg-[#173D30]/5 border border-[#173D30]/15 text-xs text-[#242821]/80 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <span>
            <strong className="text-[#173D30]">Menu Pricing Note:</strong> Listed prices (including Veg Fried Rice ₹160, Paneer 65 ₹270, and North Indian dishes ~₹140–₹290) are preliminary indicative references. Final bill is confirmed on order.
          </span>
          <button
            type="button"
            onClick={() => navigateTop('menu')}
            className="text-[#C86F4A] font-semibold hover:underline shrink-0 text-left sm:text-right"
          >
            Full Menu & Filters →
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
          {featuredDishes.map((dish) => (
            <DishCard key={dish.id} item={dish} onAddToCart={onAddToCart} />
          ))}
        </div>
      </section>

      {/* 3. MENU CATEGORY CARDS */}
      <section
        aria-labelledby="categories-heading"
        className="bg-white/70 border-y border-[#173D30]/10 py-14 sm:py-20"
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-2xl mb-10">
            <p className="text-xs font-semibold text-[#C86F4A]">
              Explore by Cuisine
            </p>
            <h2
              id="categories-heading"
              className="font-serif-display text-2xl sm:text-3xl font-bold text-[#173D30] mt-1"
            >
              Five Cuisines Under One Roof
            </h2>
            <p className="text-sm text-[#242821]/75 mt-2">
              Whether you are visiting with family for a full North Indian meal or stopping by with friends for cold coffee, pizza and crispy starters, explore our five curated menu sections.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-5">
            {displayCategories.map((cat, idx) => (
              <button
                key={cat.id}
                type="button"
                onClick={() => onSelectCategoryAndNavigate(cat.id)}
                className="group text-left bg-[#FFF8ED] rounded-xl border border-[#173D30]/12 p-5 flex flex-col justify-between hover:border-[#C86F4A] hover:shadow-md transition-all focus-visible:outline-2 focus-visible:outline-[#173D30]"
              >
                <div>
                  <span className="font-mono-num text-xs font-semibold text-[#C86F4A]">
                    0{idx + 1}. {cat.dishCount} Dishes
                  </span>
                  <h3 className="font-serif-display text-lg font-bold text-[#173D30] mt-1 group-hover:text-[#C86F4A] transition-colors">
                    {cat.label}
                  </h3>
                  <p className="text-xs text-[#242821]/75 mt-2 leading-relaxed">
                    {cat.shortDescription}
                  </p>
                </div>
                <div className="mt-5 pt-3 border-t border-[#173D30]/10 flex items-center justify-between text-xs font-semibold text-[#173D30] group-hover:text-[#C86F4A]">
                  <span>Browse Category</span>
                  <ArrowRight className="w-3.5 h-3.5 transition-transform group-hover:translate-x-0.5" />
                </div>
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* 4. ABOUT THE RESTAURANT */}
      <section
        aria-labelledby="home-about-heading"
        className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8"
      >
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
          <div className="lg:col-span-6">
            <div className="rounded-2xl overflow-hidden border border-[#173D30]/15 shadow-md aspect-4/3">
              <FoodImage
                src={IMAGES.NORTH_INDIAN}
                alt="Illustrative North Indian Thali and Paneer Butter Masala at Aarambh Restaurant and Cafe"
                containerClassName="w-full h-full relative"
              />
            </div>
          </div>

          <div className="lg:col-span-6 space-y-5">
            <p className="text-xs font-semibold text-[#C86F4A]">
              About {RESTAURANT_CONFIG.brandName}
            </p>
            <h2
              id="home-about-heading"
              className="font-serif-display text-2xl sm:text-3xl font-bold text-[#173D30] leading-tight"
              style={{ textWrap: 'balance' }}
            >
              A Warm Dining & Cafe Destination in Thakur Pura, Shivpuri
            </h2>
            <p className="text-sm sm:text-base text-[#242821]/80 leading-relaxed">
              Conveniently situated in front of Katha Mill, near Panchmukhi Hanuman Temple in Thakur Pura, {RESTAURANT_CONFIG.brandName} brings together traditional Indian family dining and a relaxed modern cafe menu.
            </p>
            <p className="text-sm sm:text-base text-[#242821]/80 leading-relaxed">
              Our kitchen prepares vegetarian North Indian staples—like Paneer Butter Masala, Kaju Curry and Dal Thalis—alongside Indo-Chinese starters, pizzas, sandwiches, cold coffee and shakes, making it easy for every guest at the table to order what they enjoy most.
            </p>
            <div className="pt-2 flex flex-wrap items-center gap-4">
              <button
                type="button"
                onClick={() => navigateTop('about')}
                className="px-5 py-2.5 rounded-lg bg-[#173D30] text-[#FFF8ED] text-sm font-semibold hover:bg-[#C86F4A] transition-colors"
              >
                Read More About Us
              </button>
              <button
                type="button"
                onClick={() => navigateTop('contact')}
                className="px-5 py-2.5 rounded-lg border border-[#173D30]/25 text-[#173D30] text-sm font-semibold hover:bg-[#173D30]/5 transition-colors"
              >
                View Location & Landmark
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* 5. WHY CHOOSE US (Factual & Without Unsupported Claims) */}
      <section
        aria-labelledby="why-choose-heading"
        className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8"
      >
        <div className="bg-[#173D30] text-[#FFF8ED] rounded-2xl p-6 sm:p-10 lg:p-12 border border-[#D5AC65]/25">
          <div className="max-w-2xl mb-10">
            <p className="text-xs font-semibold text-[#D5AC65]">
              What You Can Expect
            </p>
            <h2
              id="why-choose-heading"
              className="font-serif-display text-2xl sm:text-3xl font-bold text-[#FFF8ED] mt-1"
            >
              Why Dine or Order with Aarambh
            </h2>
            <p className="text-sm text-[#FFF8ED]/80 mt-2">
              Straightforward hospitality built around menu variety, convenient local access in Thakur Pura, and direct communication.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              {
                number: '01.',
                title: 'Multi-Category Vegetarian Menu',
                body: 'From North Indian paneer curries and thalis to Chinese starters, pizza, Maggi, cold coffee and gulab jamun in one place.',
              },
              {
                number: '02.',
                title: 'Welcoming for Every Group',
                body: 'Designed for families, college students, couples, local residents and takeaway customers around Shivpuri.',
              },
              {
                number: '03.',
                title: 'Easy Landmark Location',
                body: 'Located in Thakur Pura right in front of Katha Mill, near Panchmukhi Hanuman Temple, with direct Google Maps navigation.',
              },
              {
                number: '04.',
                title: 'Direct WhatsApp & Phone Ordering',
                body: 'Build your order online and send it straight to our WhatsApp (+91 78039 29746) to confirm live availability and final billing.',
              },
            ].map((feature) => (
              <div
                key={feature.number}
                className="bg-white/5 rounded-xl p-5 border border-[#FFF8ED]/12 flex flex-col justify-between"
              >
                <div>
                  <span className="font-mono-num text-xs font-semibold text-[#D5AC65]">
                    {feature.number}
                  </span>
                  <h3 className="font-serif-display text-lg font-semibold text-[#FFF8ED] mt-1.5">
                    {feature.title}
                  </h3>
                  <p className="text-xs sm:text-sm text-[#FFF8ED]/80 mt-2 leading-relaxed">
                    {feature.body}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 6. FOOD GALLERY PREVIEW */}
      <section
        aria-labelledby="home-gallery-heading"
        className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8"
      >
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-8">
          <div>
            <p className="text-xs font-semibold text-[#C86F4A]">
              Visual Preview
            </p>
            <h2
              id="home-gallery-heading"
              className="font-serif-display text-2xl sm:text-3xl font-bold text-[#173D30] mt-1"
            >
              Cuisine & Dish Gallery
            </h2>
            <p className="text-sm text-[#242821]/75 mt-1 max-w-2xl">
              {RESTAURANT_CONFIG.imageDisclaimer}
            </p>
          </div>
          <button
            type="button"
            onClick={() => navigateTop('gallery')}
            className="inline-flex items-center gap-1.5 text-sm font-semibold text-[#173D30] hover:text-[#C86F4A] transition-colors shrink-0"
          >
            <span>Open Full Gallery</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {GALLERY_PHOTOS.slice(1, 4).map((photo) => (
            <div
              key={photo.id}
              className="rounded-xl overflow-hidden border border-[#173D30]/12 bg-white shadow-xs flex flex-col"
            >
              <div className="aspect-4/3 w-full">
                <FoodImage
                  src={photo.imageUrl}
                  alt={photo.altText}
                  containerClassName="w-full h-full relative"
                  showIllustrativeNote={photo.isIllustrative}
                />
              </div>
              <div className="p-4">
                <p className="text-xs text-[#C86F4A] font-medium">
                  {photo.category} · Illustrative Photo
                </p>
                <h3 className="font-serif-display text-base font-semibold text-[#173D30] mt-0.5">
                  {photo.title}
                </h3>
                <p className="text-xs text-[#242821]/75 mt-1 line-clamp-2">
                  {photo.caption}
                </p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 7. CUSTOMER REVIEW SECTION (Strictly hidden until real verified reviews are supplied) */}
      {RESTAURANT_CONFIG.reviews.length > 0 && (
        <section
          aria-labelledby="reviews-heading"
          className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8"
        >
          <h2
            id="reviews-heading"
            className="font-serif-display text-2xl sm:text-3xl font-bold text-[#173D30] mb-6"
          >
            Guest Reviews
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {RESTAURANT_CONFIG.reviews.map((rev) => (
              <blockquote
                key={rev.id}
                className="p-6 rounded-xl bg-white border border-[#173D30]/12 space-y-3"
              >
                <p className="text-sm text-[#242821]/85">“{rev.comment}”</p>
                <footer className="text-xs text-[#242821]/65">
                  <strong className="text-[#173D30]">{rev.customerName}</strong> ·{' '}
                  {rev.visitContext} · {rev.date}
                </footer>
              </blockquote>
            ))}
          </div>
        </section>
      )}

      {/* 8. LOCATION AND OPENING HOURS + 9. CONTACT / WHATSAPP CTA */}
      <section
        aria-labelledby="location-hours-heading"
        className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8"
      >
        <div className="bg-white rounded-2xl border border-[#173D30]/15 p-6 sm:p-10 shadow-xs">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            <div className="lg:col-span-7 space-y-4">
              <p className="text-xs font-semibold text-[#C86F4A]">
                Visit or Order from Thakur Pura, Shivpuri
              </p>
              <h2
                id="location-hours-heading"
                className="font-serif-display text-2xl sm:text-3xl font-bold text-[#173D30]"
              >
                Location, Hours & Direct WhatsApp Ordering
              </h2>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 pt-2">
                <div className="space-y-1.5">
                  <h3 className="text-xs font-semibold text-[#173D30] flex items-center gap-1.5">
                    <MapPin className="w-4 h-4 text-[#C86F4A]" aria-hidden="true" />
                    <span>Address & Landmark</span>
                  </h3>
                  <p className="text-sm text-[#242821]/80 leading-relaxed">
                    {RESTAURANT_CONFIG.location.fullAddress}
                  </p>
                </div>

                <div className="space-y-1.5">
                  <h3 className="text-xs font-semibold text-[#173D30] flex items-center gap-1.5">
                    <Clock className="w-4 h-4 text-[#C86F4A]" aria-hidden="true" />
                    <span>Opening Hours (Confirm Before Publishing)</span>
                  </h3>
                  <p className="text-sm text-[#242821]/80 font-mono-num">
                    {RESTAURANT_CONFIG.openingHours.listedHours}
                  </p>
                  <p className="text-xs text-[#242821]/65">
                    {RESTAURANT_CONFIG.openingHours.statusNote}
                  </p>
                </div>
              </div>
            </div>

            {/* Action Box */}
            <div className="lg:col-span-5 bg-[#FFF8ED] rounded-xl p-6 border border-[#173D30]/12 space-y-3">
              <h3 className="font-serif-display text-lg font-semibold text-[#173D30]">
                Ready to Order or Plan Your Visit?
              </h3>
              <p className="text-xs text-[#242821]/75">
                Call us directly, message us on WhatsApp to place a pickup/delivery order request, or open Google Maps for turn-by-turn directions.
              </p>

              <div className="space-y-2.5 pt-2">
                <button
                  type="button"
                  onClick={() => navigateTop('order')}
                  className="w-full py-3 px-4 rounded-lg bg-[#173D30] hover:bg-[#C86F4A] text-[#FFF8ED] text-sm font-semibold flex items-center justify-center gap-2 transition-colors"
                >
                  <MessageCircle className="w-4 h-4 text-[#D5AC65]" />
                  <span>Start Online Order Request</span>
                </button>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  <a
                    href={`tel:${RESTAURANT_CONFIG.contact.phoneDial}`}
                    className="py-2.5 px-3 rounded-lg border border-[#173D30]/20 hover:bg-[#173D30]/5 text-[#173D30] text-xs font-semibold flex items-center justify-center gap-1.5 font-mono-num"
                  >
                    <Phone className="w-3.5 h-3.5 text-[#C86F4A]" />
                    <span>{RESTAURANT_CONFIG.contact.phoneDisplay}</span>
                  </a>

                  <a
                    href={RESTAURANT_CONFIG.location.googleMapsUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="py-2.5 px-3 rounded-lg border border-[#173D30]/20 hover:bg-[#173D30]/5 text-[#173D30] text-xs font-semibold flex items-center justify-center gap-1.5"
                  >
                    <span>Google Maps</span>
                    <ExternalLink className="w-3.5 h-3.5 text-[#C86F4A]" />
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};
