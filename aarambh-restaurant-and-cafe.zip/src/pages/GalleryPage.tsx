import React, { useState } from 'react';
import { Info, Utensils, X } from 'lucide-react';
import { GalleryPhoto, PageId } from '../types/restaurant';
import {
  RESTAURANT_CONFIG,
  GALLERY_PHOTOS,
  MENU_ITEMS,
} from '../data/restaurantConfig';
import { FoodImage } from '../components/FoodImage';

interface GalleryPageProps {
  onNavigate: (page: PageId) => void;
}

export const GalleryPage: React.FC<GalleryPageProps> = ({ onNavigate }) => {
  const [selectedFilter, setSelectedFilter] = useState<string>('All');
  const [lightboxPhoto, setLightboxPhoto] = useState<GalleryPhoto | null>(null);

  const categories = [
    'All',
    'Dining Atmosphere',
    'North Indian',
    'Indo-Chinese',
    'Desserts & Beverages',
  ];

  const filteredPhotos =
    selectedFilter === 'All'
      ? GALLERY_PHOTOS
      : GALLERY_PHOTOS.filter((p) => p.category === selectedFilter);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-14 space-y-10">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 border-b border-[#173D30]/15 pb-8">
        <div className="space-y-2 max-w-3xl">
          <p className="text-xs font-semibold text-[#C86F4A]">
            Visual Cuisine Showcase
          </p>
          <h1 className="font-serif-display text-3xl sm:text-4xl font-bold text-[#173D30]">
            Food & Cafe Gallery
          </h1>
          <p className="text-sm sm:text-base text-[#242821]/80">
            Explore visual highlights representing the North Indian curries, sizzling Indo-Chinese starters, cafe beverages and desserts available on our menu at {RESTAURANT_CONFIG.brandName}.
          </p>
        </div>

        <button
          type="button"
          onClick={() => {
            onNavigate('menu');
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
          className="px-5 py-2.5 rounded-lg bg-[#173D30] hover:bg-[#C86F4A] text-[#FFF8ED] text-xs sm:text-sm font-semibold inline-flex items-center gap-2 self-start md:self-auto shrink-0 transition-colors"
        >
          <Utensils className="w-4 h-4 text-[#D5AC65]" />
          <span>Order from Menu</span>
        </button>
      </div>

      {/* Explicit Illustrative Photo Disclosure */}
      <div
        role="note"
        className="p-4 rounded-xl bg-white border border-[#173D30]/15 flex items-start gap-3 text-xs sm:text-sm text-[#242821]/85"
      >
        <Info className="w-5 h-5 text-[#173D30] shrink-0 mt-0.5" aria-hidden="true" />
        <div>
          <strong className="text-[#173D30]">Illustrative Imagery Notice: </strong>
          <span>{RESTAURANT_CONFIG.imageDisclaimer}</span>
        </div>
      </div>

      {/* Filter Buttons */}
      <div className="flex items-center gap-1.5 p-1.5 bg-[#173D30]/8 rounded-xl overflow-x-auto w-fit max-w-full">
        {categories.map((cat) => {
          const active = selectedFilter === cat;
          return (
            <button
              key={cat}
              type="button"
              onClick={() => setSelectedFilter(cat)}
              className={`px-4 py-2 rounded-lg text-xs sm:text-sm font-semibold transition-colors whitespace-nowrap shrink-0 ${
                active
                  ? 'bg-[#173D30] text-[#FFF8ED]'
                  : 'text-[#242821]/80 hover:text-[#173D30] hover:bg-white/60'
              }`}
            >
              {cat}
            </button>
          );
        })}
      </div>

      {/* Main Gallery Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {filteredPhotos.map((photo) => (
          <figure
            key={photo.id}
            className="bg-white rounded-2xl border border-[#173D30]/12 overflow-hidden shadow-xs flex flex-col justify-between group"
          >
            <button
              type="button"
              onClick={() => setLightboxPhoto(photo)}
              className="text-left block w-full focus-visible:outline-2 focus-visible:outline-[#173D30]"
              aria-label={`View larger image of ${photo.title}`}
            >
              <div className="aspect-16/9 w-full overflow-hidden">
                <FoodImage
                  src={photo.imageUrl}
                  alt={photo.altText}
                  containerClassName="w-full h-full relative"
                  className="w-full h-full object-cover transition-transform duration-200 group-hover:scale-[1.02]"
                  showIllustrativeNote={photo.isIllustrative}
                />
              </div>
            </button>

            <figcaption className="p-5 sm:p-6 space-y-2">
              <div className="flex items-center gap-2 text-xs text-[#242821]/65">
                <span className="font-semibold text-[#C86F4A]">{photo.category}</span>
                <span aria-hidden="true">·</span>
                <span>Illustrative Culinary Representation</span>
              </div>
              <h2 className="font-serif-display text-xl font-bold text-[#173D30]">
                {photo.title}
              </h2>
              <p className="text-sm text-[#242821]/80 leading-relaxed">
                {photo.caption}
              </p>
            </figcaption>
          </figure>
        ))}
      </div>

      {/* Dish Highlights Index */}
      <div className="bg-white/80 rounded-2xl border border-[#173D30]/12 p-6 sm:p-8 space-y-4">
        <h2 className="font-serif-display text-xl font-bold text-[#173D30]">
          Popular Dishes Featured Across Our Menu Categories
        </h2>
        <p className="text-xs sm:text-sm text-[#242821]/75">
          All dishes below are available to add to your WhatsApp order request on our Menu page:
        </p>
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3 pt-2">
          {MENU_ITEMS.map((dish) => (
            <button
              key={dish.id}
              type="button"
              onClick={() => {
                onNavigate('menu');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className="text-left p-3 rounded-lg bg-[#FFF8ED] border border-[#173D30]/10 hover:border-[#C86F4A] transition-colors"
            >
              <p className="text-xs font-semibold text-[#173D30] truncate">
                {dish.name}
              </p>
              <p className="text-[11px] text-[#242821]/65 font-mono-num mt-0.5">
                {dish.categoryLabel} · ₹{dish.price}*
              </p>
            </button>
          ))}
        </div>
      </div>

      {/* Accessible Lightbox Modal */}
      {lightboxPhoto && (
        <div
          role="dialog"
          aria-modal="true"
          aria-labelledby="lightbox-title"
          className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4"
        >
          <div className="bg-[#FFF8ED] rounded-2xl max-w-3xl w-full overflow-hidden shadow-2xl border border-[#D5AC65]/30">
            <div className="flex items-center justify-between px-5 py-3.5 bg-[#173D30] text-[#FFF8ED]">
              <h3 id="lightbox-title" className="font-serif-display text-base font-semibold">
                {lightboxPhoto.title}
              </h3>
              <button
                type="button"
                onClick={() => setLightboxPhoto(null)}
                aria-label="Close image preview"
                className="p-1.5 rounded-lg hover:bg-white/10"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="aspect-16/9 w-full bg-black">
              <FoodImage
                src={lightboxPhoto.imageUrl}
                alt={lightboxPhoto.altText}
                containerClassName="w-full h-full relative"
              />
            </div>
            <div className="p-5 space-y-1">
              <p className="text-sm text-[#242821]">{lightboxPhoto.caption}</p>
              <p className="text-xs text-[#C86F4A]">
                Note: Representative culinary stock/illustrative photography.
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
