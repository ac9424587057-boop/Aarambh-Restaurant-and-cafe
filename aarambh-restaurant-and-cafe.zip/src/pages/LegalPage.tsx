import React from 'react';
import { ShieldCheck, FileText, Globe } from 'lucide-react';
import { RESTAURANT_CONFIG } from '../data/restaurantConfig';

export const LegalPage: React.FC = () => {
  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-16 space-y-12">
      {/* Page Header */}
      <div className="border-b border-[#173D30]/15 pb-8 space-y-2">
        <p className="text-xs font-semibold text-[#C86F4A]">
          {RESTAURANT_CONFIG.brandName} · Legal & Website Policies
        </p>
        <h1 className="font-serif-display text-3xl sm:text-4xl font-bold text-[#173D30]">
          Privacy Policy & Terms for Online Enquiries / Orders
        </h1>
        <p className="text-sm text-[#242821]/75">
          Applicable to online visitors and WhatsApp/telephone order enquiries for {RESTAURANT_CONFIG.brandName}, located at {RESTAURANT_CONFIG.location.fullAddress}.
        </p>
      </div>

      {/* Section 1: Terms for Online Enquiries & WhatsApp Orders */}
      <section className="bg-white rounded-2xl border border-[#173D30]/15 p-6 sm:p-8 space-y-4">
        <div className="flex items-center gap-2.5 text-[#173D30]">
          <FileText className="w-5 h-5 text-[#C86F4A]" />
          <h2 className="font-serif-display text-2xl font-bold">
            1. Terms for Online Enquiries & WhatsApp Orders
          </h2>
        </div>

        <div className="space-y-3 text-sm text-[#242821]/85 leading-relaxed">
          <p>
            <strong>Order Request Only (Not Confirmed Until Acknowledged):</strong> Submitting an order through our website’s WhatsApp order generator sends a formatted message request to our business WhatsApp number ({RESTAURANT_CONFIG.contact.phoneDisplay}). Sending a message does not automatically guarantee order acceptance, live kitchen inventory, payment completion, or delivery dispatch. An order is active only after our restaurant staff replies or confirms by phone.
          </p>
          <p>
            <strong>Preliminary / Indicative Menu Prices:</strong> All menu prices displayed on this website (such as Veg Fried Rice at ₹160, Paneer 65 at ₹270, and North Indian dishes around ₹140–₹290) are indicative sample/reference prices. Prices, portion sizes, taxes, packaging charges and item availability are subject to change and will be confirmed by {RESTAURANT_CONFIG.brandName} before finalizing your order.
          </p>
          <p>
            <strong>Illustrative Food Photography:</strong> Food and cafe images presented across this website are representative culinary illustrations and are not photographs of the restaurant premises or guaranteed plating.
          </p>
          <p>
            <strong>Opening Hours Confirmation:</strong> Our listed hours are {RESTAURANT_CONFIG.openingHours.listedHours}. Because operating hours may vary on local holidays or special occasions in Shivpuri, guests are encouraged to call {RESTAURANT_CONFIG.contact.phoneDisplay} to confirm before travelling late.
          </p>
        </div>
      </section>

      {/* Section 2: Privacy Policy */}
      <section className="bg-white rounded-2xl border border-[#173D30]/15 p-6 sm:p-8 space-y-4">
        <div className="flex items-center gap-2.5 text-[#173D30]">
          <ShieldCheck className="w-5 h-5 text-[#C86F4A]" />
          <h2 className="font-serif-display text-2xl font-bold">
            2. Privacy Policy for Website Visitors
          </h2>
        </div>

        <div className="space-y-3 text-sm text-[#242821]/85 leading-relaxed">
          <p>
            <strong>Client-Side Cart Storage:</strong> Your selected menu items and quantities are stored locally in your browser so your tray remains intact while you browse pages. You can clear your cart at any time using the "Clear Cart" button.
          </p>
          <p>
            <strong>Information Shared via WhatsApp or Phone:</strong> When you enter your name, phone number, pickup/delivery preference, address and order notes on the checkout or contact forms, that information is used solely to format your direct enquiry to {RESTAURANT_CONFIG.brandName}. We do not sell or rent customer contact numbers to third-party marketers.
          </p>
          <p>
            <strong>Third-Party Links (WhatsApp & Google Maps):</strong> Clicking "Order on WhatsApp" or "Open in Google Maps" directs you to external services operated by WhatsApp (Meta) and Google Maps, which are governed by their respective privacy policies.
          </p>
        </div>
      </section>

      {/* Section 3: Technical SEO, Sitemap & robots.txt Guidance */}
      <section className="bg-[#173D30]/5 rounded-2xl border border-[#173D30]/15 p-6 sm:p-8 space-y-4">
        <div className="flex items-center gap-2.5 text-[#173D30]">
          <Globe className="w-5 h-5 text-[#C86F4A]" />
          <h2 className="font-serif-display text-xl font-bold">
            3. Sitemap, robots.txt & Local SEO Configuration
          </h2>
        </div>

        <p className="text-xs sm:text-sm text-[#242821]/80 leading-relaxed">
          Static search engine discovery files (<code className="font-mono text-xs bg-white px-1.5 py-0.5 rounded">/robots.txt</code> and <code className="font-mono text-xs bg-white px-1.5 py-0.5 rounded">/sitemap.xml</code>) are included in the public root of this application, alongside verified Schema.org <code className="font-mono text-xs bg-white px-1.5 py-0.5 rounded">Restaurant</code> JSON-LD metadata in <code className="font-mono text-xs bg-white px-1.5 py-0.5 rounded">index.html</code>.
        </p>
      </section>
    </div>
  );
};
