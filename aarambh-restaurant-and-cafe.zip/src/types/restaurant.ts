export type PageId =
  | 'home'
  | 'menu'
  | 'about'
  | 'gallery'
  | 'contact'
  | 'order'
  | 'legal';

export type MenuCategoryId =
  | 'all'
  | 'north-indian'
  | 'chinese-starters'
  | 'fast-food'
  | 'cafe-beverages'
  | 'desserts';

export interface MenuAddOn {
  id: string;
  name: string;
  price: number;
  isSamplePrice?: boolean;
}

export interface MenuItem {
  id: string;
  name: string;
  description: string;
  price: number;
  isIndicativePrice: boolean;
  priceNote?: string;
  category: Exclude<MenuCategoryId, 'all'>;
  categoryLabel: string;
  isVegetarian: boolean;
  isAvailable: boolean;
  isFeatured?: boolean;
  spiceLevel?: 'Mild' | 'Medium' | 'Spicy' | 'Sweet' | 'Refreshing';
  servingSize?: string;
  image: string;
  imageAlt: string;
  isIllustrativeImage: boolean;
  addOns?: MenuAddOn[];
}

export interface CartItem {
  cartItemId: string;
  menuItem: MenuItem;
  quantity: number;
  selectedAddOns: MenuAddOn[];
  specialRequest?: string;
}

export interface CustomerReview {
  id: string;
  customerName: string;
  visitContext: string;
  date: string;
  comment: string;
  verified: boolean;
}

export interface GalleryPhoto {
  id: string;
  title: string;
  category: 'North Indian' | 'Indo-Chinese' | 'Cafe & Fast Food' | 'Desserts & Beverages' | 'Dining Atmosphere';
  caption: string;
  imageUrl: string;
  altText: string;
  isIllustrative: boolean;
  aspectRatio: '16:9' | '4:3';
}

export interface RestaurantConfig {
  brandName: string;
  shortName: string;
  tagline: string;
  supportingIntro: string;
  location: {
    area: string;
    city: string;
    state: string;
    postalCode: string;
    country: string;
    landmarkReference: string;
    fullAddress: string;
    googleMapsUrl: string;
  };
  contact: {
    phoneDisplay: string;
    phoneDial: string;
    whatsappNumber: string; // E.164 without plus for wa.me
  };
  openingHours: {
    listedHours: string;
    statusNote: string;
    isConfirmedForPublishing: boolean;
    scheduleSummary: string;
  };
  currency: {
    code: string;
    symbol: string;
  };
  pricingDisclaimer: {
    shortLabel: string;
    bannerText: string;
    checkoutNotice: string;
  };
  imageDisclaimer: string;
  targetCustomers: string[];
  reviews: CustomerReview[]; // Empty until real verified reviews are supplied
}

export interface CheckoutFormData {
  customerName: string;
  phoneNumber: string;
  orderPreference: 'pickup' | 'delivery';
  deliveryAddress: string;
  landmark?: string;
  orderNotes: string;
}
